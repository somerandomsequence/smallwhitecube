#!/usr/bin/env ruby

$:.unshift(File.dirname(__FILE__))
require 'util'
include Util

OutputDir="user_traces"
InCap="trace.cap"

Dir.mkdir(OutputDir) unless File.directory? OutputDir

$stderr.puts "Read in list of good clients"
good_clients = Array.new
File.open("good_clients.txt","r"){ |fh|
  fh.each_line{ |line|
    line.chomp!
    good_clients.push line
  }
}

good_clients.each{ |climac|
  climac = mac_add_colons(climac)
  $stderr.puts "Doing client #{climac}"
  `tshark -E header=n -l -r #{InCap} -Tfields -e frame.time_delta_displayed -e frame.len -R 'wlan.da == #{climac} && wlan.fc.type == 2' | grep -v 'Negative length' > #{OutputDir}/#{climac}_down.txt`
  `tshark -E header=n -l -r #{InCap} -Tfields -e frame.time_delta_displayed -e frame.len -R 'wlan.sa == #{climac} && wlan.fc.type == 2' | grep -v 'Negative length' > #{OutputDir}/#{climac}_up.txt`
}
