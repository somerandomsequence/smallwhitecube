#!/bin/bash

PCAP=$1

# How about this for a one-liner, eh?
# That's tshark | ruby | sort
#
# Outputs a "<BSSID> <count>" histogram with the most frequent on the first line

tshark -E separator=\| -l -r $PCAP -Tfields -e wlan.bssid | \
	ruby -e 'macs = {}; $stdin.each_line{ |l| l.chomp!; next if l =~ /^\s*$/ or l =~ /ff:ff:ff:ff:ff:ff/i; \
	macs[l] = 0 if macs[l].nil?; macs[l] += 1}; macs.each{ |m,c| puts "#{m} #{c}" }' | \
	sort -nr -k 2
