#!/bin/bash

INCAP=$1
OUTCAP=$2
BSSID=$3

tshark -r $1 -R "wlan.bssid == $3" -w $2
