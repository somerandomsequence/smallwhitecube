#!/bin/bash
pcap=$1
text=$2
tshark -E header=y -E separator=\| -l -r $pcap -Tfields -e frame.time_relative -e frame.len -e wlan.fc.pwrmgt -e wlan.fc.type -e wlan.fc.type_subtype -e wlan.sa -e wlan.da | bzip2 -z - > $text.bz2
