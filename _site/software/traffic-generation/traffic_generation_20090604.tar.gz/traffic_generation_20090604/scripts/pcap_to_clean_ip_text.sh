#!/bin/bash

PCAP=$1
TEXT=$2

tshark -r $PCAP -R 'ip && !malformed' -E header=y -E separator=\| -l -Tfields -e frame.time_relative -e frame.len -e wlan.sa -e wlan.da -e ip.src -e ip.dst -e ip.checksum_good -e ip.fcs_good | bzip -z - > $TEXT.bz2
