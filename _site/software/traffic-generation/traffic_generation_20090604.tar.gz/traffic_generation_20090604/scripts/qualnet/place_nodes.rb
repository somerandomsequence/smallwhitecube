#!/usr/bin/env ruby

Width=400
Height=400
Nodes=8

first = true
(1..Nodes).each{ |nid|
  tag = first ? " # AP" : ""
  puts "#{sprintf('%03d',nid)} 0S (#{sprintf('%.02f',rand*Width)}, #{sprintf('%.02f',rand*Height)}, 0.0) #{tag}"
  first = false if first
}
