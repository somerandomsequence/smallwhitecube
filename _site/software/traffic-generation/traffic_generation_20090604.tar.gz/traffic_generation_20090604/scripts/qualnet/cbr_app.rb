#!/usr/bin/env ruby

Nodes=(ARGV[0].nil?) ? 8 : ARGV[0].to_i
MinPPS=(ARGV[1].nil?) ? 1 : ARGV[1].to_i
MaxPPS=(ARGV[2].nil?) ? 40 : ARGV[40].to_i
ActiveNodes=(ARGV[3].nil?) ? 3 : ARGV[3].to_i

# defaults based on choices in:
# @inproceedings{513823,
#  author = {Mineo Takai and Jay Martin and Rajive Bagrodia and Aifeng Ren},
#  title = {Directional virtual carrier sensing for directional antennas in mobile ad hoc networks},
#  booktitle = {MobiHoc '02: Proceedings of the 3rd ACM international symposium on Mobile ad hoc networking \& computing},
#  year = {2002},
#  isbn = {1-58113-501-7},
#  pages = {183--193},
#  location = {Lausanne, Switzerland},
#  doi = {http://doi.acm.org/10.1145/513800.513823},
#  publisher = {ACM},
#  address = {New York, NY, USA},
# }

picked = []
(1..ActiveNodes).each{ |n|
  pps = rand*(MaxPPS-MinPPS) + MinPPS
  p = nil
  while p.nil?
    t = rand(Nodes)+1
    unless picked.include? t
      picked.push t
      p = t
    end
  end
  d = rand(Nodes)+1
  # CBR 2 5 0 512 1S 2S 0 PRECEDENCE 0  
  puts "CBR #{p} #{d} 0 512 #{(1000/pps).to_i}MS 10S 0S"
}
