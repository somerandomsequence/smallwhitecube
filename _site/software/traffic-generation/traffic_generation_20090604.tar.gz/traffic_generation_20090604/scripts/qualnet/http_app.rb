#!/usr/bin/env ruby

# usage: ./foo.rb <NumNodes> <ServersPerClient> <ActiveNodes> <MaxThinkTime>

# default values based on choices in:
#
# @inproceedings{570660,
#  author = {Ronny Krashinsky and Hari Balakrishnan},
#  title = {Minimizing energy for wireless web access with bounded slowdown},
#  booktitle = {MobiCom '02: Proceedings of the 8th annual international conference on Mobile computing and networking},
#  year = {2002},
#  isbn = {1-58113-486-X},
#  pages = {119--130},
#  location = {Atlanta, Georgia, USA},
#  doi = {http://doi.acm.org/10.1145/570645.570660},
#  publisher = {ACM},
#  address = {New York, NY, USA},
# }

Nodes=(ARGV[0].nil?) ? 8 : ARGV[0].to_i
ServersPerClient=(ARGV[1].nil?) ? 1 : ARGV[1].to_i
ActiveNodes=(ARGV[2].nil?) ? 1 : ARGV[2].to_i
MaxThinkTime=(ARGV[3].nil?) ? 1000 : ARGV[3].to_i

puts "HTTPD 1"
picked = []
(1..ActiveNodes).each{ |n|
  p = nil
  while p.nil?
    t = rand(Nodes)+1
    next if t == 1
    unless picked.include? t
      picked.push t
      p = t
    end
  end
  puts "HTTP #{p} 1 1 3S #{MaxThinkTime}S"
}
