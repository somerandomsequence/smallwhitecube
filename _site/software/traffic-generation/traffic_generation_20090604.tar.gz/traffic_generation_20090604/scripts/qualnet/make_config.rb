#!/usr/bin/env ruby

require "yaml"

YFile=ARGV[0].nil? ? "config.yaml" : ARGV[0]
IFile=ARGV[1].nil? ? "combined_index.txt" : ARGV[1]

# give Array a shuffle method
class Array
  def shuffle!
    size.downto(1) { |n| push delete_at(rand(n)) }
    self
  end
end

def cluster_select(y,sim_cluster)
  cluster_needs = {}
  if sim_cluster == "proportional"
  elsif sim_cluster == "even"
    b = (y["nodes"].length-1)/3
    r = (y["nodes"].length-1)-(b*3)
    # first put the base in each bucket
    cluster_needs[1] = cluster_needs[2] = cluster_needs[3] = b
    # then randomly, but fairly assign the remainder
    (1..r).each{ |dc| 
      pick = rand(3)+1
      while cluster_needs[pick] > b # don't drop two of the remainder in the same bucket
        pick = rand(3)+1
      end
      cluster_needs[pick] += 1
    }
  else
    # all one cluster
    cluster_needs[1] = cluster_needs[2] = cluster_needs[3] = 0
    cluster_needs[sim_cluster.to_i] = y["nodes"].length-1
  end
  return cluster_needs
end

def in_percentile_range(v,data,p)
  p_bottom,p_top = p
  i_bottom = ((p_bottom.to_f/100)*data.length).floor
  i_top = ((p_top.to_f/100)*data.length).floor - 1
  v = v.to_f
  #puts "#{v}? #{data[i_bottom]}@#{i_bottom} - #{data[i_top]}@#{i_top}"
  res = v >= data[i_bottom].to_f and v <= data[i_top].to_f
  return res
end

def select_column(col,table)
  table.collect{ |h| h[col].to_f }.sort
end

ifields = nil
index = Array.new
File.open(IFile,"r"){ |fh|
  ifields = fh.gets.split(/\s+/)
  fh.each_line{ |l|
    new_rec = {}
    n = 0
    l.split(/\s+/).each{ |i|
      new_rec[ifields[n]] = i
      n += 1
    }
    new_rec["used-by"] = nil
    index.push new_rec
  }
}
index.shuffle!

# we're just going to generate an app where all session traffic goes to and from
# a single AP and assume all clients want to do something...

y = YAML::load_file(YFile)
min_session = (y["minSession"].nil?) ? 60 : y["minSession"].to_i
tx_sim_cluster = (y["txSimilarityClusterWeighting"].nil?) ? "proportional" : y["txSimilarityClusterWeighting"]
tx_cluster_needs = cluster_select(y,tx_sim_cluster)
rx_sim_cluster = (y["rxSimilarityClusterWeighting"].nil?) ? "proportional" : y["rxSimilarityClusterWeighting"]
rx_cluster_needs = cluster_select(y,rx_sim_cluster)
tx_allan_percentile = y["txPacketAllanDeviation"]
rx_allan_percentile = y["rxPacketAllanDeviation"]
the_ap = nil

tx_allan = select_column("tx-pkt-allan-dev",index)
rx_allan = select_column("rx-pkt-allan-dev",index)

y["nodes"].each{ |n|
  if n["ap"]
    the_ap = n["id"]
    next
  end
  found = false

  index.each{ |i|
    # try to reject it
    next unless File.exists?(i["upstream-trace-path"]) and File.exists?(i["downstream-trace-path"])
    next if i["session-length"].to_i < min_session
    next if (!n["minSession"].nil?) and (i["session-length"].to_i < n["minSession"].to_i)
    next unless i["used-by"].nil?
    next if (tx_sim_cluster != "proportional") and (tx_cluster_needs[i["tx-sim-cluster"].to_i] <= 0)
    next if (rx_sim_cluster != "proportional") and (rx_cluster_needs[i["rx-sim-cluster"].to_i] <= 0)
    next unless tx_allan_percentile.nil? or in_percentile_range(i["tx-pkt-allan-dev"],tx_allan,tx_allan_percentile)
    next unless rx_allan_percentile.nil? or in_percentile_range(i["tx-pkt-allan-dev"],rx_allan,rx_allan_percentile)
    i["used-by"] = n["id"] # okay, accept it
    tx_cluster_needs[i["tx-sim-cluster"].to_i] -= 1 unless tx_sim_cluster == "proportional" # adjust needs
    rx_cluster_needs[i["rx-sim-cluster"].to_i] -= 1 unless rx_sim_cluster == "proportional"
    found = true
    break
  } 
  unless found
    $stderr.puts "Could not satisfy requirements! Could not find a candidate for node #{n['id']}"
    $stderr.puts "TX Cluster Needs: #{tx_cluster_needs.sort.collect{ |a| a[1] }.join("|")}"
    $stderr.puts "RX Cluster Needs: #{rx_cluster_needs.sort.collect{ |a| a[1] }.join("|")}"
    $stderr.puts "TX Allan Percentile: #{tx_allan_percentile.join(" - ")}%" unless tx_allan_percentile.nil?
    $stderr.puts "RX Allan Percentile: #{rx_allan_percentile.join(" - ")}%" unless rx_allan_percentile.nil?
    exit 1
  end
}

# print out config
index.each{ |i|
  next if i["used-by"].nil?
  c = i["used-by"]
  # this spec is defined on p. 152 of the QualNet-4.0-ModelLibrary-Developer doc
  puts "TRAFFIC-TRACE #{c} #{the_ap} DET 0 DET #{i["session-length"].to_i}S TRC #{i["upstream-trace-path"]} NOLB"
  puts "TRAFFIC-TRACE #{the_ap} #{c} DET 0 DET #{i["session-length"].to_i}S TRC #{i["downstream-trace-path"]} NOLB"
}
