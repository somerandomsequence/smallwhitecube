#!/usr/bin/env ruby

NumSplits=ARGV[0].to_i
ThePath=ARGV[2]
WhichPart=ARGV[1]

n = 0
File.open("combined_index.txt","r"){ |fh|
  fh.gets
  fh.each_line{ |l|
    n += 1
  }
}

puts n

r = n % NumSplits
co = n / NumSplits

p = 0
i = 0
while i < n-1
  c = co
  if r > 0
    c += 1
    r -= 1
  end
  a = i
  b = (i+c)-1

  puts "#{a} #{b}"
  fh = File.open("#{p}_split.sh","w");
  fh.puts "#!/bin/bash"
  fh.puts "pushd #{ThePath}"
  fh.puts "ruby scripts/sim_split_run_#{WhichPart}.rb #{a} #{b}"
  fh.puts "popd"
  fh.close
  i = b+1
  p += 1
end
