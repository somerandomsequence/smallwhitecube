#!/usr/bin/env ruby

# sensors self and redundant (i.e. symmetric) points

seen = {}
File.open("sim.log","r"){ |fh|
  puts fh.gets.chomp # header
  fh.each_line{ |l|
    i1,i2,stx,srx = l.chomp.split(/\s+/)
    i1 = i1.to_i
    i2 = i2.to_i
    next if i1 == i2
    next unless seen["#{i1}-#{i2}"].nil? and seen["#{i2}-#{i1}"].nil?
    puts "#{i1} #{i2} #{stx} #{srx}"
    seen["#{i1}-#{i2}"] = seen["#{i2}-#{i1}"] = 1
  }
}
