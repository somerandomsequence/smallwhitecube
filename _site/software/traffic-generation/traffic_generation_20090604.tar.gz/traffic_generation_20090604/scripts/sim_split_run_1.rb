#!/usr/bin/env ruby

# calc all the HMMs and get the seq's prepped

From=ARGV[0].to_i
To=ARGV[1].to_i

TxFieldNum=2
RxFieldNum=3
NumStates=4
ErrLog="sim_data/#{From}_#{To}.err.log"

todo = []
File.open("combined_index.txt","r"){ |fh|
  fh.gets # skip header
  fh.each_line{ |l|
    id,dir,mac = l.chomp.split(/\s+/)
    id = id.to_i
    next unless (id >= From) and (id <= To)
    todo.push([id,dir,mac])
  }
}

`date > #{ErrLog}`
todo.each{ |id,dir,mac|
  fname = "#{dir}/client_model_1.0/#{mac}.txt"
  `cut -f #{TxFieldNum} -d ' ' #{fname} > sim_data/#{id}.tx.seq.txt`
  `cut -f #{RxFieldNum} -d ' ' #{fname} > sim_data/#{id}.rx.seq.txt`
  `bin/baumwelch #{NumStates} sim_data/#{id}.tx.hmm.xml < sim_data/#{id}.tx.seq.txt 2>> #{ErrLog}`
  `bin/baumwelch #{NumStates} sim_data/#{id}.rx.hmm.xml < sim_data/#{id}.rx.seq.txt 2>> #{ErrLog}`
}
