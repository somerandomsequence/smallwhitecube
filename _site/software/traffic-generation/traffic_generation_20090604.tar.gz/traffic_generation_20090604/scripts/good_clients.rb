#!/usr/bin/env ruby

$:.unshift(File.dirname(__FILE__))
require 'util'
include Util

InCap=ARGV[0]

Verbose = true
MinPacketsPerMacPerDirection = 2
MinPacketsPerMacPerIP = 50

# count the number of packets per MAC, per IP (ips) and per MAC (macs)
up = {}
down = {}
ips = {}
bogus = {}
ph = File.popen("tshark -r #{InCap} -R 'ip && !malformed' -E separator=\\| -l -Tfields -e frame.time_relative -e frame.len -e wlan.bssid -e wlan.sa -e wlan.da -e ip.src -e ip.dst -e wlan.fc.ds","r")
ph.each_line{ |l|
  parts = l.chomp.split(/\|/)
  next if parts.length != 8
  t,l,bssid,mac_src,mac_dst,ip_src,ip_dest,ds = parts

  next if ds == "0x0"
  if ds == "0x3"
    $stderr.puts "WDS traffic!? I'm not prepared to handle that...sorry..."
    exit
  end
  direction = (ds == "0x01") ? :up : :down

  bssid = mac_norm(bssid)
  mac_src = mac_norm(mac_src)  
  ip_src = ip_norm(ip_src)
  mac_dst = mac_norm(mac_dst)

  bogus[bssid] = 1 # make sure AP doesn't get counted as a client  

  if direction == :down
    next if mac_dst == "ffffffffffff"
    down[mac_dst] = 0 if down[mac_dst].nil?
    down[mac_dst] += 1
  else
    ips[ip_src] = {} if ips[ip_src].nil?
    ips[ip_src][mac_src] = 0 if ips[ip_src][mac_src].nil?
    ips[ip_src][mac_src] += 1 
    up[mac_src] = 0 if up[mac_src].nil?
    up[mac_src] += 1
  end
}
ph.close

# okay, now let's figure out which source-macs are bogus
(up.keys + down.keys).uniq.each{ |mac|
  if up[mac].nil? or down[mac].nil? or 
     up[mac] < MinPacketsPerMacPerDirection or
     down[mac] < MinPacketsPerMacPerDirection

     $stderr.puts "#{mac} is bogus (insufficient overall traffic) u:#{up[mac]} d:#{down[mac]}" if Verbose
     bogus[mac] = 1
  end
}

# if it's not the most prolific mac associated with its given IP - or - 
# generated less than MinPacketsPerMacPerIP packets with that IP
ips.each_key{ |ip|
  unless ips[ip].length <= 1
    next if ip == "0.0.0.0"
    $stderr.puts "#{ip} appears with #{ips[ip].length} unique macs" if Verbose
    $stderr.puts ips[ip].collect{ |k,v| "   #{k}: #{v} times" }.join("\n") if Verbose

    # find the best
    max_count = 0
    max_smac = nil
    total_count = 0
    ips[ip].each{ |smac,count|
      if count > max_count
        max_smac = smac
        max_count = count
      end
      total_count += 1
    }

    ips[ip].each{ |smac,count|
      if (smac != max_smac) and (count < MinPacketsPerMacPerIP)
        $stderr.puts "marking #{smac} for #{ip} as bogus"
        bogus[smac] = 1
      end
    }
  end
}


# output the good macs
(up.keys + down.keys).uniq.each{ |mac|
  puts mac if bogus[mac].nil?
}

