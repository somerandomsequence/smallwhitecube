ia = load('matlab_data.txt');
if length(ia) == 0
  fprintf(2,'NA,NA,NA\n');
  quit;
end
ia_zero_censored = ia([ia(:,1) > 0],1);
fit = lognfit(ia_zero_censored);
lik = lognlike(fit,ia_zero_censored);
mu = fit(1);
sig = fit(2);
fprintf(2,'%f,%f,%f\n',mu,sig,lik);
