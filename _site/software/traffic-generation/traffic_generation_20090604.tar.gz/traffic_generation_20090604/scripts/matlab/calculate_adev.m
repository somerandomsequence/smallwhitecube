addpath('scripts/matlab');
p = load('matlab_data.txt');
tau0 = 1.0;
[sig,sig2,osig,msig,tsig,tau] = avar(p(:,1),tau0);
a = sig2(1); % index i is for tau = i*tau0
fprintf(2,'%f\n',a);
