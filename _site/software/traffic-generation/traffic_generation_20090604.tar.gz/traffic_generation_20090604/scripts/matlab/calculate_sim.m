% setup path
p={'scripts/matlab', ...
   'scripts/matlab/similarity-0.1', ...
   'scripts/matlab/similarity-0.1/HMMall' ...
   'scripts/matlab/similarity-0.1/HMMall/HMM', ...
   'scripts/matlab/similarity-0.1/HMMall/KPMstats', ...
   'scripts/matlab/similarity-0.1/HMMall/KPMtools', ...
   'scripts/matlab/similarity-0.1/HMMall/netlab3.3'};
for i = 1:length(p)
  addpath(char(p(i)))
end

% load data_dirs
set_data_dirs

% read in data
macs=cell(1,length(data_dirs));
for i = 1:length(data_dirs)
    data_dirs{i}
    cd(data_dirs{i});
    fid = fopen('good_clients.txt','r');
    tmp = fscanf(fid,'%c\n');
    num_users = length(tmp)/12;
    macs{i} = cell(1,num_users);
    for j = 1:num_users
        from = ((j-1)*12)+1;
        to = from+11;
        macs{i}{j} = tmp(from:to);
    end
    fclose(fid);
    cd('..');
end


% load activity traces and do factorial similarity
bucket_lens=[1.0];
activity_traces_per_user=cell(1,length(data_dirs));
for i = 1:length(data_dirs)
    cd(data_dirs{i});
    activity_traces_per_user{i}=cell(1,length(macs{i}));
    for j = 1:length(macs{i})
        mac = macs{i}(j);
        activity_traces_per_user{i}{j} = load(char(strcat('client_model_1.0/',mac,'.txt')));
    end
    cd '..';
end

% to resume from some point, comment this in:
%load('matlab.mat')

if ~exist('activity_sim_between_users_tx') || isempty(activity_sim_between_users_tx)
    activity_sim_between_users_tx = cell(1,length(data_dirs));
end
if ~exist('activity_sim_between_users_rx') || isempty(activity_sim_between_users_rx)
    activity_sim_between_users_rx = cell(1,length(data_dirs));
end
if ~exist('hmm_tx') || isempty(hmm_tx)
    hmm_tx = cell(1,length(data_dirs));
end
if ~exist('hmm_rx') || isempty(hmm_rx)
    hmm_rx = cell(1,length(data_dirs));
end
for i = 1:length(data_dirs)
    if isempty(activity_sim_between_users_tx{i})
        activity_sim_between_users_tx{i}=cell(1,length(macs{i}));
    end
    if isempty(activity_sim_between_users_rx{i})
        activity_sim_between_users_rx{i}=cell(1,length(macs{i}));
    end
    for j = 1:length(macs{i})
        if isempty(activity_sim_between_users_tx{i}{j})
            activity_sim_between_users_tx{i}{j} = cell(1,length(data_dirs));
        end
        if isempty(activity_sim_between_users_rx{i}{j})
            activity_sim_between_users_rx{i}{j} = cell(1,length(data_dirs));
        end
        for k = 1:length(data_dirs)
            if isempty(activity_sim_between_users_tx{i}{j}{k})
                activity_sim_between_users_tx{i}{j}{k} = cell(1,length(macs{k}));
            end
            if isempty(activity_sim_between_users_rx{i}{j}{k})
                activity_sim_between_users_rx{i}{j}{k} = cell(1,length(macs{k}));
            end
            if isempty(hmm_tx{k})
              hmm_tx{k} = cell(1,length(macs{k}))
            end
            if isempty(hmm_rx{k})
              hmm_rx{k} = cell(1,length(macs{k}))
            end
            for l = 1:length(macs{k})
                i
                j
                k
                l
                if isempty(hmm_tx{i}{j})
                    hmm_tx{i}{j} = 0;
                end
                if isempty(hmm_rx{i}{j})
                    hmm_rx{i}{j} = 0;
                end
                if isempty(hmm_tx{k}{l})
                    hmm_tx{k}{l} = 0;
                end
                if isempty(hmm_rx{k}{l})
                    hmm_rx{k}{l} = 0;
                end
                if isempty(activity_sim_between_users_tx{i}{j}{k}{l})
                    [sigma,P,l1,l2] = similarity(activity_traces_per_user{i}{j}(:,2)',activity_traces_per_user{k}{l}(:,2)',4,hmm_tx{i}{j},hmm_tx{k}{l});
                    activity_sim_between_users_tx{i}{j}{k}{l} = sigma;
                    hmm_tx{i}{j} = l1;
                    hmm_tx{k}{l} = l2;
                end
                if isempty(activity_sim_between_users_rx{i}{j}{k}{l})
                    [sigma,P,l1,l2] = similarity(activity_traces_per_user{i}{j}(:,3)',activity_traces_per_user{k}{l}(:,3)',4,hmm_rx{i}{j},hmm_rx{k}{l});
                    activity_sim_between_users_rx{i}{j}{k}{l} = sigma;
                    hmm_rx{i}{j} = l1;
                    hmm_rx{k}{l} = l2;
                end
            end
        end
    end
    save
end

c = 0;
flatten = cell(1,length(data_dirs));
for i = 1:length(data_dirs)
    flatten{i} = cell(1,length(macs{i}));
    for j = 1:length(macs{i})
        c = c + 1;
        flatten{i}{j} = c;
    end
end

flat_sim_rx = ones(c,c)*0;
flat_sim_tx = ones(c,c)*0;
for i = 1:length(data_dirs)
    for j = 1:length(macs{i})
        for k = 1:length(data_dirs)
            for l = 1:length(macs{k})
                % deal with overruns and underruns
                arx = activity_sim_between_users_rx{i}{j}{k}{l};
                if arx >= 1
                  arx = 1;
                end
                if arx <= 0 
                  arx = 0;
                end
                atx = activity_sim_between_users_tx{i}{j}{k}{l};
                if atx >= 1 
                  atx = 1;
                end
                if atx <= 0
                  atx = 0;
                end
                flat_sim_rx(flatten{i}{j},flatten{k}{l}) = arx;
                flat_sim_tx(flatten{i}{j},flatten{k}{l}) = atx;
                % force symmetry
		flat_sim_rx(flatten{k}{l},flatten{i}{j}) = arx;
		flat_sim_tx(flatten{k}{l},flatten{i}{j}) = atx;
            end
        end
    end
end

% clustering
cluster_count = 3;
flat_dissim_rx_sf = squareform(1-flat_sim_rx);
flat_dissim_tx_sf = squareform(1-flat_sim_tx);
flat_rx_cluster = cluster(linkage(flat_dissim_rx_sf),'maxclust',cluster_count);
flat_tx_cluster = cluster(linkage(flat_dissim_tx_sf),'maxclust',cluster_count);

% output
fid = fopen('cluster.txt','w');
fwrite(fid,sprintf('dir mac tx-sim-cluster rx-sim-cluster\n'));
for i = 1:length(data_dirs)
    for j = 1:length(macs{i})
        i
        j
        fwrite(fid,sprintf('%s %s %d %d\n',data_dirs{i},macs{i}{j},flat_tx_cluster(flatten{i}{j}),flat_rx_cluster(flatten{i}{j})));
    end
end
fclose(fid);

