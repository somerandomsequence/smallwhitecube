sim.to.dist <- function(s,switch){
  n <- max(s$id1)+1
  r <- matrix(nrow=n-1,ncol=n-1)
  for(i in seq(1,n-1,1)){
    s1 <- s[s$id1 == i,]
    r[i,i] = r[i,i] = 1
    if(i < n-1){
      for(j in seq(i+1,n-1,1)){
        #print(paste(i,j))
        s3 = s1[s1$id2 == j,]
        if(switch == 'tx'){
          r[i,j] = r[j,i] = s3$sim.tx
        }else{
          r[i,j] = r[j,i] = s3$sim.tx
        }
      }
    }
  }
  # turn matrix into dist object and get the complement
  # i.e., dissimilarity instead of similarity
  as.dist(1-r)
}

library(stats)

s <- read.table('sim.log',header=TRUE)

print(paste("TX/RX Correlation: ",cor(s$sim.tx,s$sim.rx)))

txd <- sim.to.dist(s,'tx')
rxd <- sim.to.dist(s,'rx')

n.clusters <- 3

txk <- kmeans(txd,n.clusters)
rxk <- kmeans(rxd,n.clusters)
write.table(data.frame(tx=txk$cluster,rx=rxk$cluster),quote=FALSE,file="cluster.txt");
