#!/bin/bash
w=`whoami`
for i in `qstat | grep $w | cut -b 1-10`;do qdel $i;done
