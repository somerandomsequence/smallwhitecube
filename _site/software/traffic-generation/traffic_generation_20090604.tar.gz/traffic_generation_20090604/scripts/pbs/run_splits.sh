#!/bin/bash
for i in `ls *_split.sh`;do
  echo $i
  qsub -l nodes=1:ppn=1 -l walltime=24:00:00 $i
done
