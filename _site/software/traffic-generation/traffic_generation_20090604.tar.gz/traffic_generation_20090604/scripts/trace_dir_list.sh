#!/bin/bash
ls -1 */trace.cap | cut -f 1 -d '/'
