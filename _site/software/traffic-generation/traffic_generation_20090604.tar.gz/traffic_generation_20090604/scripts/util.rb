module Util

def mac_norm(a)
  return nil if a.nil?
  return a.strip.tr(':','').downcase
end

def ip_norm(a)
  a.strip
end

# some miscellaneous utility functions
def mac_add_colons(source)
  "#{source[0..1]}:#{source[2..3]}:#{source[4..5]}:#{source[6..7]}:#{source[8..9]}:#{source[10..11]}"
end

def compare_macs(a,b)
  if a.nil? or b.nil?
    false
  else
    mac_norm(a) == mac_norm(b)
  end
end

end
