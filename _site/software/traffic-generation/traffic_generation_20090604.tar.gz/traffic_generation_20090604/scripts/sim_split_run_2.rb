#!/usr/bin/env ruby

# calc all the similarities

From=ARGV[0].to_i
To=ARGV[1].to_i

ErrLog="sim_data/#{From}_#{To}.err.log"
SimLog="sim_data/#{From}_#{To}.sim.log"

mine = []
all = []
File.open("combined_index.txt","r"){ |fh|
  fh.gets # skip header
  fh.each_line{ |l|
    id,dir,mac = l.chomp.split(/\s+/)
    id = id.to_i
    mine.push([id,dir,mac]) if (id >= From) and (id <= To)
    all.push([id,dir,mac])
  }
}

of = File.open(SimLog,"w")
`date > #{ErrLog}`
mine.each{ |id,dir,mac|
  all.each{ |id2,dir2,mac2|
    puts "#{id} #{id2}"
    sigma_tx = `bin/similarity sim_data/#{id}.tx.hmm.xml sim_data/#{id2}.tx.hmm.xml sim_data/#{id}.tx.seq.txt sim_data/#{id2}.tx.seq.txt 2>> #{ErrLog}`
    sigma_rx = `bin/similarity sim_data/#{id}.rx.hmm.xml sim_data/#{id2}.rx.hmm.xml sim_data/#{id}.rx.seq.txt sim_data/#{id2}.rx.seq.txt 2>> #{ErrLog}`
    if sigma_tx =~ /sigma = ([\d\.]+)/
      sigma_tx = $1
    else
      `echo Failed to get sigma for TX/#{id} >> #{ErrLog}`
    end
    if sigma_rx =~ /sigma = ([\d\.]+)/
      sigma_rx = $1
    else
      `echo Failed to get sigma for RX/#{id} >> #{ErrLog}`
    end
    of.puts "#{id} #{id2} #{sigma_tx} #{sigma_rx}"
  }
}
of.close
