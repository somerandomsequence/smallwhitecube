#!/usr/bin/env ruby

$:.unshift(File.dirname(__FILE__))
require 'util'
include Util

States={:active => 1,:idle => 2, :sleeping => 3, :gone => 4}
IdleTimeout=10*60
BucketLen=(ARGV[0].nil?) ? 1.0 : ARGV[0].to_f
OutputDir="client_model_#{BucketLen}"
InCap="trace.txt.bz2"
FrameTypes={:man => 0, :ctl => 1, :dat => 2}
FrameSubtypes={:null => 0x24, :pspoll => 0x1a}

$stderr.puts "Read in list of good clients"
good_clients = Array.new
File.open("good_clients.txt","r"){ |fh|
  fh.each_line{ |line|
    line.chomp!
    good_clients.push line
  }
}

Dir.mkdir(OutputDir) unless File.directory? OutputDir

class Bucket
  def initialize(n)
    @n = n
    @tx_state = :idle
    @rx_state = :idle
    @tx_count = 0
    @rx_count = 0
    @tx_len = 0
    @rx_len = 0
  end
  
  def count_tx(len)
    @tx_len += len
    @tx_count += 1
    @tx_state = :active
  end
  
  def count_rx(len)
    @rx_len += len
    @rx_count += 1
    @rx_state = :active
  end
  
  def to_s(ps)
    @rx_state = :sleeping if ps and (@rx_state == :idle)
    @tx_state = :sleeping if ps and (@tx_state == :idle)
    "#{@n} #{States[@tx_state]} #{States[@rx_state]} #{@tx_count} #{@rx_count} #{@tx_len} #{@rx_len}"
  end
  
  attr_reader :n
end

# look at each client - would be way more efficient to do them all at the
# same time, but program correctness is more important than speed here IMHO
good_clients.each{ |climac|
  $stderr.puts "Doing client #{climac}"
  outfile = "#{OutputDir}/#{climac}.txt"
  of = File.new(outfile,"w")
  
  relevant_frame_count = 0
  current_bucket = nil
  powersaving = false
  
  wph = File.popen("bzip2 -d -c #{InCap}","r")
  wph.each_line{ |line|
    # frame.time_relative|frame.len|wlan.fc.pwrmgt|wlan.fc.type|wlan.fc.type_subtype|wlan.sa|wlan.da
    # 0.000000000|237|0|0|0x08|11:7e:5d:6b:a8:ad|ff:ff:ff:ff:ff:ff
    begin
      ts,len,pwr_mgt,type,subtype,sa,da = line.chomp.split(/\|/)
      sa = mac_norm(sa)
      da = mac_norm(da)
      ts = ts.to_f
      len = len.to_i
      pwr_mgt = (pwr_mgt.to_i == 1)
      type = type.to_i
      subtype = subtype.to_i(16)
    rescue
      $stderr.puts "Trouble in paradise!\nLine: #{line}"
      $stderr.puts "As Parsed: " + [ts,len,pwr_mgt,type,subtype,sa,da].join(" ")
      $stderr.puts $!
      next
    end
    
    # skip irrelevant frames
    next unless compare_macs(climac,sa) or compare_macs(climac,da)
    next unless type == FrameTypes[:dat]
    relevant_frame_count += 1
    
    bucket_num = (ts/BucketLen).ceil
    upstream = compare_macs(climac,sa)
    
    if relevant_frame_count == 1
      current_bucket = Bucket.new(bucket_num)
    elsif bucket_num > current_bucket.n
      elapsed = bucket_num-current_bucket.n
      # ouput the last frame
      of.puts current_bucket.to_s(powersaving)
      # output silent frames if necessary
      if elapsed > 1
        (current_bucket.n+1..bucket_num-1).each{ |ebnum|
          txs = (powersaving) ? :sleeping : :idle
          rxs = (powersaving) ? :sleeping : :idle
          txs = :gone if ((ebnum-current_bucket.n)*BucketLen) >= IdleTimeout
          rxs = :gone if ((ebnum-current_bucket.n)*BucketLen) >= IdleTimeout
          of.puts "#{ebnum} #{States[txs]} #{States[rxs]} 0 0 0 0"
        }
      end
      # need a new "current"
      current_bucket = Bucket.new(bucket_num)
    end
    
    # count this frame
    if upstream
      # don't count frames that are just about communicating (PS) state
      # control and management frames are already skipped explicitly above...
      current_bucket.count_tx(len) unless subtype == FrameSubtypes[:null]
    else
      current_bucket.count_rx(len)
    end
    powersaving = pwr_mgt
  }
  # remember to output last bucket
  of.puts current_bucket.to_s(powersaving)
  of.close
  wph.close
}
