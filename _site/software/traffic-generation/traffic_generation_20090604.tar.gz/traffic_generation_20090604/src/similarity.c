#include <stdlib.h>
#include <math.h>
#include <ghmm/ghmm.h>
#include <ghmm/model.h>
#include <ghmm/sequence.h>

#include <common.h>

void usage(){
  fprintf(stderr,"Usage: similarity <lambda1.xml> <lambda2.xml> <obs1.txt> <obs2.txt>\n");
  exit(EXIT_USAGE);
}

int main(int argc, const char* argv[]){
  ghmm_dmodel *l1;
  ghmm_dmodel *l2;
  int dc = 0;
  FILE *fh1 = NULL;
  FILE * fh2 = NULL;
  ghmm_dseq* s1;
  ghmm_dseq* s2;
  double p11, p12, p21, p22, sigma;

  if(argc < 5) usage();
  
  // load models
  if(DEBUG) fprintf(stderr,"loading models...\n");
  if((l1 = *ghmm_dmodel_xml_read(argv[1],&dc)) == NULL){
    fprintf(stderr,"ghmm_dmodel_xml_read failed for %s\n",argv[1]);
    return EXIT_MISC;
  }
  if((l2 = *ghmm_dmodel_xml_read(argv[2],&dc)) == NULL){
    fprintf(stderr,"ghmm_dmodel_xml_read failed for %s\n",argv[2]);
    return EXIT_MISC;
  }

  if(DEBUG) fprintf(stderr,"reading in sequences...\n");
  if((fh1 = fopen(argv[3],"r")) == NULL){
    fprintf(stderr,"fopen failed on %s\n",argv[3]);
    return EXIT_MISC;
  }
  if((s1 = read_sequence(fh1)) == NULL){
    fprintf(stderr,"read_sequence failed on %s\n",argv[3]);
    return EXIT_MISC;
  }
  fclose(fh1);

  if((fh2 = fopen(argv[4],"r")) == NULL){
    fprintf(stderr,"fopen failed on %s\n",argv[4]);
    return EXIT_MISC;
  }
  if((s2 = read_sequence(fh2)) == NULL){
    fprintf(stderr,"read_sequence failed on %s\n",argv[4]);
    return EXIT_MISC;
  }
  fclose(fh2);

  if(DEBUG) fprintf(stderr,"running forward algorithm 4 times...\n");
  // these are actually lpij = log(p(Oi|lambdaj))
  p11 = ghmm_dmodel_likelihood(l1,s1);
  p12 = ghmm_dmodel_likelihood(l2,s1);
  p21 = ghmm_dmodel_likelihood(l1,s2);
  p22 = ghmm_dmodel_likelihood(l2,s2);

  // we want pij = p(Oi|lambdaj)^(1/|Oi|)
  // but observe from eq. 7 in the paper cited above:
  // p11 = e^(lpij/|Oi|)
  // (substituting in e for 10 since this log is nat. log)
  if(DEBUG) fprintf(stderr,"scale probs and calculate sigma...\n");
  p11 = exp(p11/((double)s1->seq_len[0]));
  p22 = exp(p22/((double)s2->seq_len[0]));
  p12 = exp(p12/((double)s1->seq_len[0]));
  p21 = exp(p21/((double)s2->seq_len[0]));
  sigma = sqrt((p12*p21)/(p11*p22));

  if(sigma > 1.0){
    fprintf(stderr,"Warning: sigma > 1.0\n");
    sigma = 1.0;
  }else if(sigma < 0.0){
    fprintf(stderr,"Warning: sigma < 0.0\n");
    sigma = 0.0;
  }

  printf("sigma = %f\n",sigma);

  // hrm... these seem to cause problems
  //ghmm_dseq_free(&s1);
  //ghmm_dseq_free(&s2);
  //ghmm_dmodel_free(&l1);
  //ghmm_dmodel_free(&l2);

  return EXIT_NORMAL;
}


