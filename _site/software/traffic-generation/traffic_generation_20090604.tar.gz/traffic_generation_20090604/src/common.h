#ifndef COMMON_H
#define COMMON_H

#include <ghmm/sequence.h>

#define BUFFER_SIZE 512
#define SEQ_CHUNK_SIZE 1024

#define EXIT_NORMAL 0
#define EXIT_USAGE 1
#define EXIT_MALLOC 2
#define EXIT_MISC 3

#define DEBUG 0

ghmm_dseq *read_sequence(FILE* fh){
  char buffer[BUFFER_SIZE];
  int olen = 0;
  int *o = NULL;
  int *o2 = NULL;
  int oi = 0;
  ghmm_dseq* seq;

  while(fgets(buffer,BUFFER_SIZE,fh) != NULL){
    // expand o if necessary
    if(oi >= olen){
      olen = olen + SEQ_CHUNK_SIZE;
      if((o2 = (int*)malloc(olen*sizeof(int))) == NULL) return NULL;
      for(int i = 0; i < (olen-SEQ_CHUNK_SIZE);i++) o2[i] = o[i];
      free(o);
      o = o2;
    }

    o[oi] = atoi(buffer)-1;
    oi++;
  }

  // setup ghmm seq structure
  if((seq = ghmm_dseq_calloc(1)) == NULL) return NULL;
  seq->seq_len[0] = oi;
  seq->seq_id[0] = 0.0; // not really sure what this is for
  seq->seq[0] = o;
  return seq;
}

#endif
