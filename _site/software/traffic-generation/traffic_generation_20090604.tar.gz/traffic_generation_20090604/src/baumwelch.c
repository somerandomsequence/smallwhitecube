#include <stdlib.h>
#include <ghmm/ghmm.h>
#include <ghmm/randvar.h>
#include <ghmm/matrix.h>
#include <ghmm/sequence.h>
#include <ghmm/reestimate.h>

#include <common.h>

void usage(){
  fprintf(stderr,"Usage: baumwelch <N> <outfile.xml>\n");
  exit(EXIT_USAGE);
}

double **random_stochastic_matrix(const int n, const int m){
  double** r = ighmm_cmatrix_alloc(n,m);
  double s = 0.0;
  for(int i = 0; i < n; i++){
    s = 0.0;
    for(int j = 0; j < m; j++){
      r[i][j] = ighmm_rand_uniform_int(0,1000);
      s += r[i][j];
    }
    // make sure the row sums to 1 by dividing by the sum
    for(int j = 0; j < m; j++) r[i][j] = r[i][j]/s;
  }
  return r;
}

int main(int argc, const char* argv[]){
  int N = 4;
  ghmm_dseq* seq;
  ghmm_dmodel* model;
  int *degrees = NULL;
  int *ids = NULL;
  double **a = NULL;
  double **b = NULL;
  double **pi = NULL;
  ghmm_alphabet *alpha = NULL;
  char **symbols = NULL;
  
  if(argc < 3) usage();
  N = atoi(argv[1]);
  if(DEBUG) fprintf(stderr,"%d states\n",N);

  if((seq = read_sequence(stdin)) == NULL){
    fprintf(stderr,"read_sequence failed\n");
    return EXIT_MISC;
  }
  if(DEBUG) fprintf(stderr,"Read in %d values from stdin\n",seq->seq_len[0]);
   
  // initialize random model as a starting point
  if((degrees = (int*)malloc(N*sizeof(int))) == NULL){
    fprintf(stderr,"malloc failed\n");
    return EXIT_MALLOC;
  }
  if((ids = (int*)malloc(N*sizeof(int))) == NULL){
    fprintf(stderr,"malloc failed\n");
    return EXIT_MALLOC;
  }
  // since indegree and outdegree is N for all states, 
  // this is an "ergodic" (i.e. normal) HMM
  for(int i = 0; i < N; i++) degrees[i] = N;
  for(int i = 0; i < N; i++) ids[i] = i;
  // N is the number of states AND output symbols
  if((model = ghmm_dmodel_calloc(N,N,GHMM_kDiscreteHMM,degrees,degrees)) == NULL){
    fprintf(stderr,"ghmm_dmodel_calloc failed\n");
    return EXIT_MALLOC;
  }
  model->prior = -1.0;

  pi = random_stochastic_matrix(1,N);
  b = random_stochastic_matrix(N,N);
  a = random_stochastic_matrix(N,N);
  for(int i = 0; i < N; i++){
    model->s[i].pi = pi[0][i];
    model->s[i].b = b[i];
    model->s[i].in_id = ids;
    model->s[i].out_id = ids;
    model->s[i].out_states = N;
    model->s[i].in_states = N;
  }
  // must do this, after all that...
  for(int i = 0; i < N; i++)
    for(int j = 0; j < N; j++) 
      ghmm_dmodel_set_transition(model,i,j,a[i][j]);

  // alphabet foolishness
  alpha = (ghmm_alphabet*)malloc(sizeof(ghmm_alphabet));
  symbols = (char **)malloc(N*sizeof(char *));
  for(int i = 0; i < N; i++){
    symbols[i] = (char *)malloc(2);
    // ASCII offset for '0' is 48, and plus 1, cuz we want to do 1 to N
    symbols[i][0] = 48+i+1;
    symbols[i][1] = 0;
  }
  alpha->size = N;
  alpha->id = 0;
  alpha->description = "wtf?";
  alpha->symbols = symbols;
  model->alphabet = alpha;

  if(DEBUG) ghmm_dmodel_print(stderr,model);

  // check the model before continuing
  if(ghmm_dmodel_check(model) != 0){
    fprintf(stderr,"ghmm_dmodel_check failed\n");
    ghmm_dmodel_print(stderr,model);
    return EXIT_MALLOC;
  }

  // do EM
  if(ghmm_dmodel_baum_welch(model,seq) < 0){
    fprintf(stderr,"ghmm_dmodel_baum_welch failed\n");
    return EXIT_MISC;
  }

  if(DEBUG) ghmm_dmodel_print(stderr,model);
  
  // output portable rep to stdout
  if(ghmm_dmodel_xml_write(&model,argv[2],1) < 0){
    fprintf(stderr,"ghmm_dmodel_xml_write failed\n");
    return EXIT_MISC;
  }

  // hrm...these seem to cause problems...
  //ghmm_dseq_free(&seq);
  //ghmm_dmodel_free(&model);

  return EXIT_NORMAL;
}
