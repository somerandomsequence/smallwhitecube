#include <stdio.h>
#include <string.h>

#include "gdal/ogr_api.h"
#include "gdal/ogr_srs_api.h"

#define VERBOSE 0

#define OKAY 0
#define USAGE_ERROR 1
#define GDAL_ERROR 2
#define SPATIAL_REFERENCE_ERROR 3
#define FILE_OPEN_FAIL 4

void usage(){
  fprintf(stderr,"shp_get <file> <x> <y> <layer> <fieldname> [source_srs]\n");
  exit(USAGE_ERROR);
}

int main(int argc, char **argv){
  OGRDataSourceH hDS;
  OGRLayerH hLayer;
  double adfPixelGeoTransform[6];
  double adfGeoPixelTransform[6];
  const char *default_source_srs = "WGS84";
  char *source_srs, *layer, *fieldname;
  const char *dest_srs;
  double source_geox, source_geoy, dest_geox, dest_geoy, dest_geoz;
  int i;
  OGRSpatialReferenceH hDestSRS, hSourceSRS;
  OGRCoordinateTransformationH hSourceDest;
  OGRGeometryH p;
  OGRFeatureH f;

  if(argc < 6) usage();

  OGRRegisterAll();

  if((hDS = OGROpen(argv[1],FALSE,NULL)) == NULL){
    fprintf(stderr,"Error: Failed to Open Data Source\n");
    return FILE_OPEN_FAIL;
  }

  layer = strdup(argv[4]);
  fieldname = strdup(argv[5]);
  hLayer = OGR_DS_GetLayerByName(hDS,layer);
  hDestSRS = OGR_L_GetSpatialRef(hLayer);
  OGR_L_ResetReading(hLayer);

  if(argc > 6) source_srs = strdup(argv[6]);
  else source_srs = strdup(default_source_srs);
  hSourceSRS = OSRNewSpatialReference(NULL);
  if(OSRSetWellKnownGeogCS(hSourceSRS,source_srs) != OGRERR_NONE){
    fprintf(stderr,"Error: Failed to Grok The Source Spatial Reference Code '%s'\n",source_srs);
    return SPATIAL_REFERENCE_ERROR;
  }

  source_geox = atof(argv[2]);
  source_geoy = atof(argv[3]);

  dest_geox = source_geox;
  dest_geoy = source_geoy;

  if(!OSRIsSame(hSourceSRS,hDestSRS)){
    hSourceDest = OCTNewCoordinateTransformation(hSourceSRS,hDestSRS);
    if(!OCTTransform(hSourceDest,1,&dest_geox,&dest_geoy,&dest_geoz)){
      fprintf(stderr,"Error: Failed to Translate from Source (%s) to Native/Data (%s) Spatial Reference\n",source_srs,dest_srs);
      return SPATIAL_REFERENCE_ERROR;
    }
  }

  p = OGR_G_CreateGeometry(wkbPoint);
  OGR_G_AssignSpatialReference(p,hDestSRS);
  OGR_G_SetPoint(p,0,dest_geox,dest_geoy,dest_geoz);
  OGR_L_SetSpatialFilter(hLayer,p);

  while((f = OGR_L_GetNextFeature(hLayer)) != NULL){
    /*i = 0;
    while(i < OGR_F_GetFieldCount(f)){
      printf("%f ",OGR_F_GetFieldAsDouble(f,i));
      i++;
    }
    printf("\n");*/
    //OGR_F_DumpReadable(f,stdout);
    i = OGR_F_GetFieldIndex(f,fieldname);
    printf("%f\n",OGR_F_GetFieldAsDouble(f,i));
  }

  OSRDestroySpatialReference(hDestSRS);
  OSRDestroySpatialReference(hSourceSRS);

  return OKAY;
}
