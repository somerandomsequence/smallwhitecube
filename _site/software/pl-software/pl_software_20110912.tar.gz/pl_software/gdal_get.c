#include <stdio.h>
#include <string.h>

#include "gdal.h"
#include "ogr_srs_api.h"

#define VERBOSE 0

#define OKAY 0
#define USAGE_ERROR 1
#define GDAL_ERROR 2
#define SPATIAL_REFERENCE_ERROR 3
#define FILE_OPEN_FAIL 4

void usage(){
  fprintf(stderr,"gdal_get <file> <x> <y> [source_srs]\n");
  exit(USAGE_ERROR);
}

int main(int argc, char **argv){
  GDALDatasetH hDataset;
  GDALRasterBandH hBand;
  double adfPixelGeoTransform[6];
  double adfGeoPixelTransform[6];
  const char *default_source_srs = "WGS84";
  char *source_srs;
  const char *dest_srs;
  double pixelx, pixely, source_geox, source_geoy, dest_geox, dest_geoy, dest_geoz;
  float r;
  OGRSpatialReferenceH hDestSRS, hSourceSRS;
  OGRCoordinateTransformationH hSourceDest;

  if(argc < 4) usage();

  GDALAllRegister();

  if((hDataset = GDALOpen(argv[1],GA_ReadOnly)) == NULL){
    fprintf(stderr,"Error: Failed to Open Data Source\n");
    return FILE_OPEN_FAIL;
  }

  if(GDALGetGeoTransform(hDataset,adfPixelGeoTransform) == CE_None){
    GDALInvGeoTransform(adfPixelGeoTransform,adfGeoPixelTransform);
  }else{
    fprintf(stderr,"Error: Failed To Acquire Geo -> Pixel Transform\n");
    return GDAL_ERROR;
  }

  dest_srs = GDALGetProjectionRef(hDataset);

  if(argc > 4) source_srs = strdup(argv[4]);
  else source_srs = strdup(default_source_srs);

  source_geox = atof(argv[2]);
  source_geoy = atof(argv[3]);

  hDestSRS = OSRNewSpatialReference(dest_srs); // build from WKT text
  hSourceSRS = OSRNewSpatialReference(NULL);
  if(OSRSetWellKnownGeogCS(hSourceSRS,source_srs) != OGRERR_NONE){
    fprintf(stderr,"Error: Failed to Grok The Source Spatial Reference Code '%s'\n",source_srs);
    return SPATIAL_REFERENCE_ERROR;
  }

  dest_geox = source_geox;
  dest_geoy = source_geoy;

  if(!OSRIsSame(hSourceSRS,hDestSRS)){
    hSourceDest = OCTNewCoordinateTransformation(hSourceSRS,hDestSRS);
    if(!OCTTransform(hSourceDest,1,&dest_geox,&dest_geoy,&dest_geoz)){
      fprintf(stderr,"Error: Failed to Translate from Source (%s) to Native/Data (%s) Spatial Reference\n",source_srs,dest_srs);
      return SPATIAL_REFERENCE_ERROR;
    }
  }

  GDALApplyGeoTransform(adfGeoPixelTransform, dest_geox, dest_geoy, &pixelx, &pixely);

  // FIXME: should handle out of bounds errors

  hBand = GDALGetRasterBand(hDataset,1);
  GDALRasterIO(hBand,GF_Read,pixelx,pixely,1,1,&r,1,1,GDT_Float32,0,0);
  if(VERBOSE)
    printf("%f %f (%s) -> %f %f (%s) -> %f %f (pixel) => %f\n",source_geox,source_geoy,source_srs,dest_geox,dest_geoy,dest_srs,pixelx,pixely,r);
  else
    printf("%f\n",r);

  OSRDestroySpatialReference(hDestSRS);
  OSRDestroySpatialReference(hSourceSRS);

  return OKAY;
}
