#include <stdlib.h>
#include <stdio.h>

#define SMALL_BUFLEN 32
#define N_HEADER_LINES 6

#define OKAY 0
#define USAGE_ERROR 1
#define ROW_NOT_FOUND 2
#define COL_NOT_FOUND 3
#define NUM_READ_FAIL 4
#define BUFFER_OVERFLOW 5
#define FILE_OPEN_FAIL 6

void usage(){
  fprintf(stderr,"aai_get <file> <row> <col>\n");
  exit(USAGE_ERROR);
}

int main(int argc, char **argv){
  if(argc < 4) usage();
  char buffer[SMALL_BUFLEN];
  char *filename = argv[1];
  unsigned int row = atoi(argv[2]);
  unsigned int col = atoi(argv[3]);
  FILE *fd = fopen(filename,"r");
  if(fd == NULL) return FILE_OPEN_FAIL;
  char c = 0;
  int n = 1;
  int okay = 0;
  // FIXME: read the header to decide if we can exit early
  // in the case of an out of bounds row/col, also so we can
  // return "NA" in the case that the value is NA
  while((c = fgetc(fd)) != EOF){
    if(n == (row+N_HEADER_LINES)){
      okay = 1;
      break;
    }
    if(c == '\n') ++n;
  }
  if(!okay) return ROW_NOT_FOUND;
  // now fd points to the start of the correct line (row)
  // c should contain the first char of the line which is a space
  n = 1;
  okay = 0;
  while((c = fgetc(fd)) != EOF){
    if(c == ' ') ++n; 
    if(n == col){
      okay = 1;
      break;
    }
  }
  if(!okay) return COL_NOT_FOUND;
  // now fd points to the space right before the value we want
  n = 0;
  okay = 0;
  while((c = fgetc(fd)) != EOF){
    if(c == ' ' || c == '\n'){
      okay = 1;
      break;
    }
    if(n >= SMALL_BUFLEN){
      return BUFFER_OVERFLOW;
    }
    buffer[n] = c;
    ++n;
  }
  if(!okay) return NUM_READ_FAIL;
  buffer[n] = 0; // null terminate the string
  printf("%s\n",buffer);
  return OKAY;
}
