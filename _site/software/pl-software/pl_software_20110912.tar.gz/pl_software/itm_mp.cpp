/**
 * itm_mp.cpp
 *
 * Multiprecision C++ port of the Longley-Rice Irregular Terrain Model
 * based on the itm.cpp library distributed with Splat 1.3.0.
 *
 * See the included makefile for example of how to compile.
 *
 * License: Splat! is licensed under the GPL (banner below). The ITM code this 
 *          particular file is based on is public domain. Hence, this derivative work
 *          is also GPL'ed.
 * Author: Caleb Phillips <caleb.phillips@colorado.edu>
 * Version: 2010-04-22
 */

/****************************************************************************\
*          SPLAT!: An RF Signal Path Loss And Terrain Analysis Tool          *
******************************************************************************
*            Project started in 1997 by John A. Magliacane, KD2BD            *
*                         Last update: 10-Apr-2009                           *
******************************************************************************
*         Please consult the documentation for a complete list of            *
*            individuals who have contributed to this project.               *
******************************************************************************
*                                                                            *
*  This program is free software; you can redistribute it and/or modify it   *
*  under the terms of the GNU General Public License as published by the     *
*  Free Software Foundation; either version 2 of the License or any later    *
*  version.                                                                  *
*                                                                            *
*  This program is distributed in the hope that it will useful, but WITHOUT  *
*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or     *
*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License     *
*  for more details.                                                         *
*                                                                            *
\****************************************************************************/

/*****************************************************************************\
 *                                                                           *
 *  The following code was derived from public domain ITM code available     *
 *  at ftp://flattop.its.bldrdoc.gov/itm/ITMDLL.cpp that was released on     *
 *  June 26, 2007.  It was modified to remove Microsoft Windows "dll-isms",  *
 *  redundant and unnecessary #includes, redundant and unnecessary { }'s,    *
 *  to initialize uninitialized variables, type cast some variables,         *
 *  re-format the code for easier reading, and to replace pow() function     *
 *  calls with explicit multiplications wherever possible to increase        *
 *  execution speed and improve computational accuracy.                      *
 *                                                                           *
\*****************************************************************************/

// *************************************
// C++ routines for this program are taken from
// a translation of the FORTRAN code written by
// U.S. Department of Commerce NTIA/ITS
// Institute for Telecommunication Sciences
// *****************
// Irregular Terrain Model (ITM) (Longley-Rice)
// *************************************

#include <math.h>
#include <complex>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

#include <gmp.h>
#include <mpfr.h>
#include <mpc.h>

unsigned int P; // a global! oh noes!
#define R GMP_RNDN // RNDN => to nearest, RNDU => up, RNDD => down
#define VERBOSE 0

#define THIRD  (1.0/3.0)

// exit/return codes
#define ITM_NO_ERROR 0
#define ITM_CAUTION 1
#define ITM_DEFAULTS 2
#define ITM_INVALID 3
#define ITM_REALLY_INVALID 4
#define USAGE_ERROR 100
#define MALLOC_ERROR 101

using namespace std;

struct tcomplex
{
	mpfr_t tcreal;
	mpfr_t tcimag;
};

struct prop_type
{
	mpfr_t aref;
	mpfr_t dist;
	mpfr_t hg[2];
	mpfr_t wn;
	mpfr_t dh;
	mpfr_t ens;
	mpfr_t gme;
	mpfr_t zgndreal;
	mpfr_t zgndimag;
	mpfr_t he[2];
	mpfr_t dl[2];
	mpfr_t the[2];
	int kwx;
	int mdp;
};

struct propv_type
{
	mpfr_t sgc;
	int lvar;
	int mdvar;
	int klim;
};

struct propa_type
{
	mpfr_t dlsa;
	mpfr_t dx;
	mpfr_t ael;
	mpfr_t ak1;
	mpfr_t ak2;
	mpfr_t aed;
	mpfr_t emd;
	mpfr_t aes;
	mpfr_t ems;
	mpfr_t dls[2];
	mpfr_t dla;
	mpfr_t tha;
};

void exception_handler(const char *where){
  if(VERBOSE){
    if(mpfr_underflow_p() != 0){
      fprintf(stderr,"!!! EXCEPTION: UNDERFLOW (%s)\n",where);
    }
    if(mpfr_overflow_p() != 0){
      fprintf(stderr,"!!! EXCEPTION: OVERFLOW (%s)\n",where);
    }
    if(mpfr_nanflag_p() != 0){
      fprintf(stderr,"!!! EXCEPTION: NAN (%s)\n",where);
    }
    if(mpfr_inexflag_p() != 0){
      //fprintf(stderr,"!!! EXCEPTION: ROUNDING (%s)\n",where);
    }
    if(mpfr_erangeflag_p() != 0){
      fprintf(stderr,"!!! EXCEPTION: INVALID RESULT IN CONVERSION OR COMPARISON (%s)\n",where);
    }
  }
  mpfr_clear_flags();
}

void init_props(prop_type &prop, propv_type &propv, propa_type &propa){
  mpfr_inits(prop.aref,prop.dist,prop.hg[0],prop.hg[1],prop.wn,prop.dh,prop.ens,prop.gme,
    prop.zgndreal,prop.zgndimag,prop.he[0],prop.he[1],prop.dl[0],prop.dl[1],
    prop.the[0],prop.the[1],propv.sgc,propa.dlsa,propa.dx,propa.ael,propa.ak1,propa.ak2,
    propa.aed,propa.emd,propa.aes,propa.ems,propa.dls[0],propa.dls[1],propa.dla,propa.tha,NULL);
}

void clear_props(prop_type &prop, propv_type &propv, propa_type &propa){
  mpfr_clears(prop.aref,prop.dist,prop.hg[0],prop.hg[1],prop.wn,prop.dh,prop.ens,prop.gme,
    prop.zgndreal,prop.zgndimag,prop.he[0],prop.he[1],prop.dl[0],prop.dl[1],
    prop.the[0],prop.the[1],propv.sgc,propa.dlsa,propa.dx,propa.ael,propa.ak1,propa.ak2,
    propa.aed,propa.emd,propa.aes,propa.ems,propa.dls[0],propa.dls[1],propa.dla,propa.tha,NULL);
}

int mymin(const int &i, const int &j)
{
	if (i<j)
		return i;
	else
		return j;
}

int mymax(const int &i, const int &j)
{
	if (i>j)
		return i;
	else
		return j;
}

void mymin(mpfr_t r, const mpfr_t a, const mpfr_t b)
{
	if (mpfr_cmp(a,b) < 0)
		mpfr_set(r,a,R);
	else
	  mpfr_set(r,b,R);
}

void mymax(mpfr_t r, const mpfr_t a, const mpfr_t b)
{
	if (mpfr_cmp(a,b) > 0)
		mpfr_set(r,a,R);
	else
		mpfr_set(r,b,R);
}

void FORTRAN_DIM(mpfr_t r, const mpfr_t a, const mpfr_t b)
{
	// This performs the FORTRAN DIM function.
	// result is x-y if x is greater than y; otherwise result is 0.0

	if (mpfr_cmp(a,b) > 0)
		mpfr_sub(r,a,b,R);
	else
		mpfr_set_d(r,0.0,R);
}

void aknfe(mpfr_t r, const mpfr_t i0)
{
	mpfr_t tmp, v2;
  mpfr_inits(tmp,v2,NULL);
  mpfr_set(v2,i0,R);

	if (mpfr_cmp_d(v2,5.76) < 0){
		//a=6.02+9.11*sqrt(v2)-1.27*v2;
    mpfr_sqrt(r,v2,R);
    mpfr_mul_d(r,r,9.11,R);
    mpfr_mul_d(tmp,v2,1.27,R);
    mpfr_add_d(r,r,6.02,R);
    mpfr_sub(r,r,tmp,R);
  }else{
    //a=12.953+4.343*log(v2);
    mpfr_log(r,v2,R);
    mpfr_mul_d(r,r,4.343,R);
    mpfr_add_d(r,r,12.953,R);
  }
  
  mpfr_clears(tmp,v2,NULL);
}

void fht(mpfr_t fhtv, const mpfr_t i0, const mpfr_t i1)
{
	mpfr_t w,tmp,x,pk;
  mpfr_inits(w,tmp,x,pk,NULL);
  mpfr_set(x,i0,R);
  mpfr_set(pk,i1,R);
  
	if (mpfr_cmp_d(x,200.0) < 0)
	{
    mpfr_log(w,pk,R);
    mpfr_neg(w,w,R); // w=-log(pk);

		/* if (pk < 1e-5 || x*pow(w,3.0) > 5495.0 ) */

    mpfr_pow_ui(tmp,w,3,R);
    mpfr_mul(tmp,tmp,x,R);
		if (mpfr_cmp_d(pk,1e-5) < 0 || mpfr_cmp_d(tmp,5495.0) > 0 )
		{
			mpfr_set_d(fhtv,-117.0,R);

			if (mpfr_cmp_d(x,1.0) > 0){
        mpfr_log(tmp,x,R);
        mpfr_mul_d(tmp,tmp,17.372,R);
        mpfr_add(fhtv,fhtv,tmp,R);
      }
		}
		else{
			// fhtv=2.5e-5*x*x/pk-8.686*w-15.0;
      mpfr_mul(tmp,x,x,R);
      mpfr_mul_d(tmp,tmp,2.5e-5,R);
      mpfr_div(tmp,tmp,pk,R);
      mpfr_mul_d(fhtv,w,8.686,R);
      mpfr_sub(fhtv,tmp,fhtv,R);
      mpfr_sub_d(fhtv,fhtv,15.0,R);
    }
	}

	else
	{
    // fhtv=0.05751*x-4.343*log(x);
    mpfr_log(tmp,x,R);
    mpfr_mul_d(tmp,tmp,4.343,R);
    mpfr_mul_d(fhtv,x,0.05751,R);
    mpfr_sub(fhtv,fhtv,tmp,R);

		if (mpfr_cmp_d(x,2000.0) < 0)
		{
      mpfr_mul_d(tmp,x,-0.005,R);
      mpfr_exp(tmp,tmp,R);
      mpfr_mul(tmp,tmp,x,R);
      mpfr_mul_d(w,tmp,0.0134,R);
			//w=0.0134*x*exp(-0.005*x);
      
      mpfr_d_sub(tmp,1.0,w,R);
      mpfr_mul(fhtv,fhtv,tmp,R); // fhtv = (1.0-w)*fhtv
      
      mpfr_log(tmp,x,R);
      mpfr_mul_d(tmp,tmp,17.372,R);
      mpfr_sub_d(tmp,tmp,117.0,R);
      mpfr_mul(tmp,tmp,w,R); // tmp = w*(17.372*log(x)-117.0)
      
      mpfr_add(fhtv,fhtv,tmp,R);
			//fhtv=(1.0-w)*fhtv+w*(17.372*log(x)-117.0);
		}
	}
  mpfr_clears(w,tmp,x,pk,NULL);
}

void h0f(mpfr_t h0fv, const mpfr_t i0, const mpfr_t i1)
{
	double a[5]={25.0, 80.0, 177.0, 395.0, 705.0};
	double b[5]={24.0, 45.0,  68.0,  80.0, 105.0};
	mpfr_t q, x,tmp,r,et;
  mpfr_inits(q,x,tmp,r,et,NULL);
  mpfr_set(r,i0,R);
  mpfr_set(et,i1,R);
	int it;

	it=mpfr_get_ui(et,R);

	if (it<=0)
	{
		it=1;
		mpfr_set_d(q,0.0,R);
	}
	else if (it>=5)
	{
		it=5;
		mpfr_set_d(q,0.0,R);
	}

	else
    mpfr_sub_ui(q,et,it,R);
		//q=et-it;

	/* x=pow(1.0/r,2.0); */
  mpfr_set_d(x,1.0,R);
  mpfr_div(x,x,r,R);
	//x=(1.0/r);
  mpfr_pow_ui(x,x,2,R);
	//x*=x;
  mpfr_mul_d(tmp,x,a[it-1],R);
  mpfr_add_d(tmp,tmp,b[it-1],R);
  mpfr_mul(tmp,tmp,x,R);
  mpfr_add_d(tmp,tmp,1.0,R);
  mpfr_log(tmp,tmp,R);
  mpfr_mul_d(h0fv,tmp,4.343,R);
	//h0fv=4.343*log((a[it-1]*x+b[it-1])*x+1.0);

	if (mpfr_cmp_d(q,0.0) != 0){
    mpfr_d_sub(tmp,1.0,q,R);
    mpfr_mul(h0fv,h0fv,tmp,R); // h0fv = (1.0-q)*h0fv
      
    mpfr_mul_d(tmp,x,a[it],R);
    mpfr_add_d(tmp,tmp,b[it],R);
    mpfr_mul(tmp,tmp,x,R);
    mpfr_add_d(tmp,tmp,1.0,R);
    mpfr_log(tmp,tmp,R);
    mpfr_mul_d(tmp,tmp,4.343,R);
    mpfr_mul(tmp,tmp,q,R); // tmp = q*4.343*log((a[it]*x+b[it])*x+1.0)
    
    mpfr_add(h0fv,h0fv,tmp,R);
   
		//h0fv=(1.0-q)*h0fv+q*4.343*log((a[it]*x+b[it])*x+1.0);
  }
  mpfr_clears(q,x,tmp,r,et,NULL);
}

void ahd(mpfr_t r, const mpfr_t i0)
{
	int i;
	double a[3] = {   133.4,    104.6,     71.8};
	double b[3] = {0.332e-3, 0.212e-3, 0.157e-3};
	double c[3] = {  -4.343,   -1.086,    2.171};
  mpfr_t tmp,td;
  mpfr_inits(tmp,td,NULL);
  mpfr_set(td,i0,R);

	if (mpfr_cmp_ui(td,10e3) <= 0)
		i=0;

	else if (mpfr_cmp_ui(td,70e3) <= 0)
		i=1;
  
	else
		i=2;

  mpfr_log(tmp,td,R);
  mpfr_mul_d(tmp,tmp,c[i],R); // tmp = c[i]*log(td)
  
  mpfr_mul_d(r,td,b[i],R); // r = b[i]*td
  
  mpfr_add_d(r,td,a[i],R); 
  mpfr_add(r,tmp,r,R); // r = a[i] + r + tmp
  
  mpfr_clears(tmp,td,NULL);
}

inline void mpfr_set_uiui(mpfr_t r,const unsigned int num, const unsigned int den){
  mpfr_set_ui(r,num,R);
  mpfr_div_ui(r,r,den,R);
}

inline void mpfr_pow_uiui(mpfr_t r, const mpfr_t i0, const unsigned int num, const unsigned int den){
  mpfr_t x;
  mpfr_init(x);
  mpfr_set_uiui(x,num,den);
  mpfr_pow(r,i0,x,R);
  mpfr_clear(x);
}

inline void mpfr_set_sisi(mpfr_t r,const int num, const int den){
  mpfr_set_si(r,num,R);
  mpfr_div_si(r,r,den,R);
}

inline void mpfr_pow_sisi(mpfr_t r, const mpfr_t i0, const int num, const int den){
  mpfr_t x;
  mpfr_init(x);
  mpfr_set_sisi(x,num,den);
  mpfr_pow(r,i0,x,R);
  mpfr_clear(x);
}

void adiff(mpfr_t adiffv, const mpfr_t i0, prop_type &prop, propa_type &propa, int init)
{
  mpc_t prop_zgrnd;
	static mpfr_t wd1, xd1, afo, qk, aht, xht;
	mpfr_t a, q, pk, ds, th, wa, ar, wd, tmp,tmp2,d;
  
  if(init < 0){
    mpfr_clears(wd1, xd1, afo, qk, aht, xht, NULL);
    return;
  }
  if(init == 1){
    mpfr_inits(wd1,xd1,afo,qk,aht,xht,NULL);
  }
  
  mpc_init2(prop_zgrnd,P);
  mpc_set_fr_fr(prop_zgrnd,prop.zgndreal,prop.zgndimag,R);
	//complex<double> prop_zgnd();
  mpfr_inits(a,q,pk,ds,th,wa,ar,wd,tmp,d,tmp2,NULL);
  mpfr_set(d,i0,R);

	if (mpfr_cmp_d(d,0.0)==0)
	{ 
    mpfr_mul(q,prop.hg[0],prop.hg[1],R);
    mpfr_mul(qk,prop.he[0],prop.he[1],R);
    mpfr_sub(qk,qk,q,R);
		//q=prop.hg[0]*prop.hg[1];
		//qk=prop.he[0]*prop.he[1]-q;

		if (prop.mdp < 0) mpfr_add_ui(q,q,10,R);

    mpfr_div(wd1,qk,q,R);
    mpfr_add_ui(wd1,wd1,1,R);
    mpfr_sqrt(wd1,wd1,R);
		//wd1=sqrt(1.0+qk/q);
    mpfr_div(xd1,propa.tha,prop.gme,R);
    mpfr_add(xd1,xd1,propa.dla,R);
		//xd1=propa.dla+propa.tha/prop.gme;
    mpfr_neg(q,propa.dlsa,R);
    mpfr_div_ui(q,q,50e3,R);
    mpfr_exp(q,q,R);
    mpfr_mul_d(q,q,0.8,R);
    mpfr_d_sub(q,1.0,q,R); // q = (1.0-0.8*exp(-propa.dlsa/50e3))
    mpfr_mul(q,q,prop.dh,R);
		//q=(1.0-0.8*exp(-propa.dlsa/50e3))*prop.dh;
    mpfr_div_ui(tmp,q,16,R);
    mpfr_pow_uiui(tmp,tmp,1,4);
    mpfr_neg(tmp,tmp,R);
    mpfr_exp(tmp,tmp,R);
    mpfr_mul_d(tmp,tmp,0.78,R); // tmp = 0.78*exp(-pow(q/16.0,0.25));
    mpfr_mul(q,q,tmp,R);
		//q*=0.78*exp(-pow(q/16.0,0.25));
    mpfr_mul(tmp,q,prop.wn,R);
    mpfr_mul(tmp,tmp,prop.hg[1],R);
    mpfr_mul(tmp,tmp,prop.hg[0],R);
    mpfr_mul_d(tmp,tmp,4.77e-4,R);
    mpfr_add_d(tmp,tmp,1.0,R);
    mpfr_log(tmp,tmp,R);
    mpfr_mul_d(tmp,tmp,2.171,R); // tmp = 2.171*log(1.0+4.77e-4*prop.hg[0]*prop.hg[1]*prop.wn*q)
    mpfr_set_d(afo,15.0,R); // afo = 15.0
    mymin(afo,afo,tmp);
		//afo=mymin(15.0,2.171*log(1.0+4.77e-4*prop.hg[0]*prop.hg[1]*prop.wn*q));
    
    mpc_abs(qk,prop_zgrnd,R);
    mpfr_d_div(qk,1.0,qk,R);
		//qk=1.0/abs(prop_zgnd);
    mpfr_set_ui(aht,20,R);
		//aht=20.0;
    mpfr_set_ui(xht,0,R);
		//xht=0.0;

		for (int j=0; j<2; ++j)
		{
			/* a=0.5*pow(prop.dl[j],2.0)/prop.he[j]; */
      mpfr_mul(a,prop.dl[j],prop.dl[j],R);
      mpfr_div(a,a,prop.he[j],R);
      mpfr_mul_d(a,a,0.5,R);
			//a=0.5*(prop.dl[j]*prop.dl[j])/prop.he[j];
      mpfr_set_ui(wa,1,R);
      mpfr_set_uiui(wa,1,3);
      mpfr_mul(tmp,a,prop.wn,R);
      mpfr_pow(wa,tmp,wa,R);
			//wa=pow(a*prop.wn,THIRD);
      mpfr_div(pk,qk,wa,R);
			//pk=qk/wa;
      mpfr_d_sub(q,1.607,pk,R);
      mpfr_mul_ui(q,q,151,R);
      mpfr_mul(q,q,wa,R);
      mpfr_mul(q,q,prop.dl[j],R);
      mpfr_div(q,q,a,R);
			//q=(1.607-pk)*151.0*wa*prop.dl[j]/a;
      mpfr_add(xht,xht,q,R);
			//xht+=q;
      fht(tmp,q,pk);
      mpfr_add(aht,aht,tmp,R);
			//aht+=fht(q,pk);
		}
    mpfr_set_ui(adiffv,0,R);
		//adiffv=0.0;
	}
	else
	{
    mpfr_mul(th,d,prop.gme,R);
    mpfr_add(th,th,propa.tha,R);
		//th=propa.tha+d*prop.gme;
    mpfr_sub(ds,d,propa.dla,R);
		//ds=d-propa.dla;
		/* q=0.0795775*prop.wn*ds*pow(th,2.0); */
    mpfr_mul(q,th,th,R);
    mpfr_mul(q,q,ds,R);
    mpfr_mul(q,q,prop.wn,R);
    mpfr_mul_d(q,q,0.0795775,R);
		//q=0.0795775*prop.wn*ds*th*th;
    mpfr_add(adiffv,ds,prop.dl[0],R);
    mpfr_mul(tmp,q,prop.dl[0],R);
    mpfr_div(tmp,tmp,adiffv,R); 
    aknfe(tmp,tmp); // tmp = aknfe(q*prop.dl[0]/(ds+prop.dl[0]))
    
    mpfr_add(adiffv,ds,prop.dl[1],R);
    mpfr_div(adiffv,prop.dl[1],adiffv,R);
    mpfr_mul(adiffv,q,adiffv,R);
    aknfe(adiffv,adiffv); // adiffv = aknfe(q*prop.dl[1]/(ds+prop.dl[1]))
    
    mpfr_add(adiffv,tmp,adiffv,R);
		//adiffv=aknfe(q*prop.dl[0]/(ds+prop.dl[0]))+aknfe(q*prop.dl[1]/(ds+prop.dl[1]));
    
    mpfr_div(a,ds,th,R);
		//a=ds/th;
    mpfr_set_uiui(tmp,1,3);
    mpfr_mul(wa,a,prop.wn,R);
    mpfr_pow(wa,wa,tmp,R);
		//wa=pow(a*prop.wn,THIRD);
    mpfr_div(pk,qk,wa,R);
		//pk=qk/wa;
    mpfr_d_sub(q,1.607,pk,R);
    mpfr_mul_ui(q,q,151,R);
    mpfr_mul(q,q,wa,R);
    mpfr_mul(q,q,th,R);
    mpfr_add(q,q,xht,R);
		//q=(1.607-pk)*151.0*wa*th+xht;
    mpfr_mul_d(ar,q,0.05751,R);
    mpfr_log(tmp,q,R);
    mpfr_mul_d(tmp,tmp,4.343,R);
    mpfr_sub(ar,ar,tmp,R);
    mpfr_sub(ar,ar,aht,R);
		//ar=0.05751*q-4.343*log(q)-aht;
    mpfr_set_d(tmp,6283.2,R);
    mpfr_neg(q,d,R);
    mpfr_div_ui(q,q,50e3,R);
    mpfr_exp(q,q,R);
    mpfr_mul_d(q,q,0.8,R);
    mpfr_d_sub(q,1.0,q,R);
    mpfr_mul(q,q,prop.dh,R);
    mpfr_mul(q,q,prop.wn,R);
    mymin(q,q,tmp); // q = mymin(((1.0-0.8*exp(-d/50e3))*prop.dh*prop.wn),6283.2);
    mpfr_div(tmp,xd1,d,R);
    mpfr_add(tmp,wd1,tmp,R);
    mpfr_mul(q,tmp,q,R);
    if(VERBOSE) mpfr_fprintf(stderr,"ADIFF: wd1 = %Rf, xd1 = %Rf, d = %Rf, prop.dh = %Rf, prop.wn = %Rf, q = %Rf\n",wd1,xd1,d,prop.dh,prop.wn,q);
		//q=(wd1+xd1/d)*mymin(((1.0-0.8*exp(-d/50e3))*prop.dh*prop.wn),6283.2);
    mpfr_sqrt(wd,q,R);
    mpfr_add_d(wd,wd,25.1,R);
    mpfr_d_div(wd,25.1,wd,R);
		//wd=25.1/(25.1+sqrt(q));
    mpfr_d_sub(tmp,1.0,wd,R);
    mpfr_mul(tmp,tmp,adiffv,R);
    mpfr_mul(adiffv,ar,wd,R);
    mpfr_add(adiffv,adiffv,tmp,R);
    mpfr_add(adiffv,adiffv,afo,R);
    if(VERBOSE) mpfr_fprintf(stderr,"ADIFF: adiffv = %Rf, ar = %Rf, wd = %Rf, afo = %Rf\n",adiffv,ar,wd,afo);
		//adiffv=ar*wd+(1.0-wd)*adiffv+afo;
	}
  mpfr_clears(a, q, pk, ds, th, wa, ar, wd, tmp,tmp2,d,NULL);
  mpc_clear(prop_zgrnd);
}

void ascat(mpfr_t ascatv, const mpfr_t i0, prop_type &prop, propa_type &propa, int init)
{
	static mpfr_t ad, rr, etq, h0s;
	mpfr_t h0, r1, r2, z0, ss, et, ett, th, q, temp, tmp, d;
  
  if(init < 0){
    mpfr_clears(ad, rr, etq, h0s, NULL);
    return;
  }
  
	mpfr_inits(h0, r1, r2, z0, ss, et, ett, th, q, temp,tmp,d,NULL);
  mpfr_set(d,i0,R);

	if (mpfr_cmp_d(d,0.0) == 0)
	{
    if(init == 1){
      mpfr_inits(ad, rr, etq, h0s,NULL);
    }
    mpfr_sub(ad,prop.dl[0],prop.dl[1],R);
		//ad=prop.dl[0]-prop.dl[1];
    mpfr_div(rr,prop.he[1],prop.he[0],R);
		//rr=prop.he[1]/prop.he[0];

		if (mpfr_cmp_d(ad,0.0) < 0)
		{
      mpfr_neg(ad,ad,R);
			//ad=-ad;
      mpfr_d_div(rr,1.0,rr,R);
			//rr=1.0/rr;
		}

    mpfr_mul_d(etq,prop.ens,-5.67e-6,R);
    mpfr_sub_d(etq,etq,2.32e-3,R);
    mpfr_mul(etq,etq,prop.ens,R);
    mpfr_add_d(etq,etq,0.031,R);
		//etq=(5.67e-6*prop.ens-2.32e-3)*prop.ens+0.031;
    mpfr_set_d(h0s,-15.0,R);
		//h0s=-15.0;
    mpfr_set_ui(ascatv,0,R);
		//ascatv=0.0;
	}

	else
	{
		if (mpfr_cmp_d(h0s,15.0) > 0) mpfr_set(h0,h0s,R);
		else
		{
      mpfr_mul(th,d,prop.gme,R);
      mpfr_add(th,th,prop.the[1],R);
      mpfr_add(th,th,prop.the[0],R);
			//th=prop.the[0]+prop.the[1]+d*prop.gme;
      mpfr_mul_ui(r2,prop.wn,2,R);
      mpfr_mul(r2,r2,th,R);
			//r2=2.0*prop.wn*th;
      mpfr_mul(r1,r2,prop.he[0],R);
			//r1=r2*prop.he[0];
      mpfr_mul(r2,r2,prop.he[1],R);
			//r2*=prop.he[1];

			if (mpfr_cmp_d(r1,0.2)<0 && mpfr_cmp_d(r2,0.2) < 0){
        mpfr_set_d(ascatv,1001.0,R);
        mpfr_clears(h0, r1, r2, z0, ss, et, ett, th, q, temp,tmp,d,NULL);
				return;  // <==== early return
      }

      mpfr_sub(tmp,d,ad,R);
      mpfr_add(ss,d,ad,R);
      mpfr_div(ss,tmp,ss,R);
			//ss=(d-ad)/(d+ad);
      mpfr_div(q,rr,ss,R);
			//q=rr/ss;
      mpfr_set_d(tmp,0.1,R);
			mymax(ss,tmp,ss);
      mymax(q,q,tmp);
      mpfr_set_ui(tmp,10,R);
      mymin(q,q,tmp);
			//q=mymin(mymax(0.1,q),10.0);
      mpfr_sub(z0,d,ad,R);
      mpfr_add(tmp,d,ad,R);
      mpfr_mul(z0,tmp,z0,R);
      mpfr_mul(z0,z0,th,R);
      mpfr_d_div(tmp,0.25,d,R);
      mpfr_mul(z0,z0,tmp,R);
			//z0=(d-ad)*(d+ad)*th*0.25/d;
			/* et=(etq*exp(-pow(mymin(1.7,z0/8.0e3),6.0))+1.0)*z0/1.7556e3; */
      mpfr_set_d(tmp,1.7,R);
      mpfr_div_ui(temp,z0,8.0e3,R);
      mymin(temp,temp,tmp);
			//temp=mymin(1.7,z0/8.0e3);
      mpfr_pow_ui(temp,temp,6,R);
			//temp=temp*temp*temp*temp*temp*temp;
      mpfr_neg(et,temp,R);
      mpfr_exp(et,et,R);
      mpfr_mul(et,et,etq,R);
      mpfr_add_ui(et,et,1,R);
      mpfr_mul(et,et,z0,R);
      mpfr_div_d(et,et,1.7556e3,R);
			//et=(etq*exp(-temp)+1.0)*z0/1.7556e3;

      mpfr_set_ui(tmp,1,R);
      mymax(ett,et,tmp);
			//ett=mymax(et,1.0);
      h0f(tmp,r1,ett);
      h0f(h0,r2,ett);
      mpfr_add(h0,h0,tmp,R);
      mpfr_mul_d(h0,h0,0.5,R);
			//h0=(h0f(r1,ett)+h0f(r2,ett))*0.5;
      mpfr_log(tmp,ett,R);
      mpfr_d_sub(tmp,1.38,tmp,R);
      mpfr_log(temp,ss,R);
      mpfr_mul(tmp,tmp,temp,R);
      mpfr_log(temp,q,R);
      mpfr_mul(tmp,tmp,temp,R);
      mpfr_mul_d(tmp,tmp,0.49,R);
      mymin(tmp,h0,tmp);
      mpfr_add(h0,h0,tmp,R);
			//h0+=mymin(h0,(1.38-log(ett))*log(ss)*log(q)*0.49);
      mpfr_set_ui(tmp,0,R);
      FORTRAN_DIM(h0,h0,tmp);
			//h0=FORTRAN_DIM(h0,0.0);

			if (mpfr_cmp_d(et,1.0) < 0){
        mpfr_d_div(tmp,1.4142,r1,R);
        mpfr_add_ui(tmp,tmp,1,R);
        mpfr_d_div(temp,1.4142,r2,R);
        mpfr_add_ui(temp,temp,1,R);
        mpfr_mul(tmp,temp,tmp,R);
        mpfr_pow_ui(tmp,tmp,2,R);
        mpfr_add(temp,r2,r1,R);
        mpfr_mul(tmp,temp,tmp,R); // tmp = pow((1.0+1.4142/r1) *(1.0+1.4142/r2),2.0)*(r1+r2)
        mpfr_add(temp,r1,r2,R);
        mpfr_add_d(temp,temp,2.8284,R); // temp = r1+r2+2.8284
        mpfr_div(tmp,tmp,temp,R);
        mpfr_log(tmp,tmp,R);
        mpfr_mul_d(tmp,tmp,4.343,R);
        mpfr_d_sub(temp,1.0,et,R);
        mpfr_mul(tmp,temp,tmp,R);
        mpfr_mul(temp,et,h0,R);
        mpfr_add(h0,temp,tmp,R);
				//h0=et*h0+(1.0-et)*4.343*log(pow((1.0+1.4142/r1) *(1.0+1.4142/r2),2.0)*(r1+r2)/(r1+r2+2.8284));
      }

			if (mpfr_cmp_d(h0,15.0)>0 && mpfr_cmp_d(h0s,0.0) >= 0) mpfr_set(h0,h0s,R);
		}

    mpfr_set(h0s,h0,R);
		//h0s=h0;
    mpfr_mul(th,d,prop.gme,R);
    mpfr_add(th,propa.tha,th,R);
		//th=propa.tha+d*prop.gme;
    
    mpfr_pow_ui(ascatv,th,4,R);
    mpfr_mul(ascatv,ascatv,prop.wn,R);
    mpfr_mul_d(ascatv,ascatv,47.7,R);
    mpfr_log(ascatv,ascatv,R);
    mpfr_mul_d(ascatv,ascatv,4.343,R); // ascatv = 4.343*log(47.7*prop.wn*pow(th,4.0))
    mpfr_mul(tmp,th,d,R);                                                                     
    ahd(tmp,tmp); // tmp = ahd(th*d)
    mpfr_add(ascatv,tmp,ascatv,R); // ascatv = ahd(th*d) +  4.343*log(47.7*prop.wn*pow(th,4.0))
    mpfr_sub_d(tmp,prop.ens,301.0,R);
    mpfr_mul_d(tmp,tmp,0.1,R);
    mpfr_neg(temp,th,R);
    mpfr_mul(temp,temp,d,R);
    mpfr_div_ui(temp,temp,40e3,R);
    mpfr_exp(temp,temp,R);
    mpfr_mul(tmp,tmp,temp,R); // tmp = 0.1*(prop.ens-301.0)*exp(-th*d/40e3)
    mpfr_sub(ascatv,ascatv,tmp,R);
    mpfr_add(ascatv,ascatv,h0,R);  
		/* ascatv=ahd(th*d)+4.343*log(47.7*prop.wn*pow(th,4.0))-0.1*(prop.ens-301.0)*exp(-th*d/40e3)+h0; */
		//ascatv=ahd(th*d)+4.343*log(47.7*prop.wn*th*th*th*th)-0.1*(prop.ens-301.0)*exp(-th*d/40e3)+h0;
	}
  mpfr_clears(h0, r1, r2, z0, ss, et, ett, th, q, temp,tmp,d,NULL);
}

void qerfi (mpfr_t r, const mpfr_t i0)
{
	mpfr_t x, t, v, tmp, q;
	double c0=2.515516698;
	double c1=0.802853;
	double c2=0.010328;
	double d1=1.432788;
	double d2=0.189269;
	double d3=0.001308;
  mpfr_inits(x,t,v,tmp,q,NULL);
  mpfr_set(q,i0,R);

  mpfr_d_sub(x,0.5,q,R);
	//x=0.5-q;
  
  mpfr_set_d(t,0.000001,R);
  mpfr_abs(v,x,R);
  mpfr_d_sub(v,0.5,v,R);
  mymax(t,v,t);
	//t=mymax(0.5-fabs(x),0.000001);
  
  mpfr_log(t,t,R);
  mpfr_mul_d(t,t,-2.0,R);
  mpfr_sqrt(t,t,R);
	//t=sqrt(-2.0*log(t));
  
  mpfr_mul_d(v,t,c2,R);
  mpfr_add_d(v,v,c1,R);
  mpfr_mul(v,v,t,R);
  mpfr_add_d(v,v,c0,R); // v = ((c2*t+c1)*t+c0)
  mpfr_mul_d(tmp,t,d3,R);
  mpfr_add_d(tmp,tmp,d2,R);
  mpfr_mul(tmp,tmp,t,R);
  mpfr_add_d(tmp,tmp,d1,R);
  mpfr_mul(tmp,tmp,t,R);
  mpfr_add_d(tmp,tmp,1.0,R); // tmp = (((d3*t+d2)*t+d1)*t+1.0)
  mpfr_div(v,v,tmp,R);
  mpfr_sub(v,t,v,R);
  
	//v=t-((c2*t+c1)*t+c0)/(((d3*t+d2)*t+d1)*t+1.0);
  
  if(VERBOSE) mpfr_fprintf(stderr,"QERFI: x = %Rf, t = %Rf, v = %Rf\n",x,t,v);

	if (mpfr_cmp_d(x,0.0) < 0) mpfr_neg(v,v,R);

	mpfr_set(r,v,R);
  
  mpfr_clears(x, t, v, tmp, q, NULL);
}

void qlrps(mpfr_t i0, mpfr_t i1, mpfr_t i2, int ipol, mpfr_t i3, mpfr_t i4, prop_type &prop)
{
	double gma=157e-9;
  mpfr_t fmhz, zsys, en0, eps, sgm, tmp;
  mpc_t prop_zgrnd, zq;
  
  mpfr_inits(fmhz, zsys, en0, eps, sgm, tmp, NULL);
  mpfr_set(fmhz,i0,R);
  mpfr_set(zsys,i1,R);
  mpfr_set(en0,i2,R);
  mpfr_set(eps,i3,R);
  mpfr_set(sgm,i4,R);
  
  mpfr_div_d(prop.wn,fmhz,47.7,R);
	//prop.wn=fmhz/47.7;
  mpfr_set(prop.ens,en0,R);
	//prop.ens=en0;

	if (mpfr_cmp_d(zsys,0.0) != 0){
    mpfr_neg(tmp,zsys,R);
    mpfr_div_d(tmp,tmp,9460.0,R);
    mpfr_exp(tmp,tmp,R);
    mpfr_mul(prop.ens,prop.ens,tmp,R);
		//prop.ens*=exp(-zsys/9460.0);
  }

  
  mpfr_div_d(prop.gme,prop.ens,179.3,R);
  mpfr_exp(prop.gme,prop.gme,R);
  mpfr_mul_d(prop.gme,prop.gme,0.04665,R);
  mpfr_d_sub(prop.gme,1.0,prop.gme,R);
  mpfr_mul_d(prop.gme,prop.gme,gma,R);
  
  if(VERBOSE) mpfr_fprintf(stderr,"QLRPS: prop.gme = %Rf, gma = %f, prop.ens = %Rf\n",prop.gme,gma,prop.ens);
  
	//prop.gme=gma*(1.0-0.04665*exp(prop.ens/179.3));
  
  mpc_init2(prop_zgrnd,P);
  mpc_init2(zq,P);
  mpc_set_fr_fr(prop_zgrnd,prop.zgndreal,prop.zgndimag,R);
  mpfr_div(tmp,sgm,prop.wn,R);
  mpfr_mul_d(tmp,tmp,376.62,R);
  mpc_set_fr_fr(zq,eps,tmp,R);
	//zq=complex<double> (eps,376.62*sgm/prop.wn);
  mpc_sub_ui(prop_zgrnd,zq,1,R);
  mpc_sqrt(prop_zgrnd,prop_zgrnd,R);
	//prop_zgnd=sqrt(zq-1.0);

	if (ipol!=0) mpc_div(prop_zgrnd,prop_zgrnd,zq,R);
  //prop_zgnd=prop_zgnd/zq;
  
  mpc_real(prop.zgndreal,prop_zgrnd,R);
  mpc_imag(prop.zgndimag,prop_zgrnd,R);

  mpc_clear(prop_zgrnd);
  mpc_clear(zq);
  mpfr_clears(fmhz, zsys, en0, eps, sgm, tmp, NULL);
}

//double abq_alos(complex<double> r)
//{
//	return r.real()*r.real()+r.imag()*r.imag();
//}

void abq_alos(mpfr_t ret, const mpc_t i0){
   mpc_t r;
   mpfr_t real, imag;
   mpc_init(r);
   mpfr_inits(real,imag,NULL);
   mpc_set(r,i0,R);
   mpc_real(real,r,R);
   mpc_imag(imag,r,R);
   if(VERBOSE) mpfr_fprintf(stderr,"ABQ-ALOS: real = %Rf, imag = %Rf\n",real,imag);
   mpfr_mul(imag,imag,imag,R);
   mpfr_mul(real,real,real,R);
   mpfr_add(ret,real,imag,R);
   mpc_clear(r);
   mpfr_clears(real,imag,NULL);
}

void alos(mpfr_t alosv, const mpfr_t i0, prop_type &prop, propa_type &propa,int init)
{
  mpc_t prop_zgrnd, r,tmpc;
  static mpfr_t wls;
	mpfr_t s, sps, q, d, tmp, tmp2;
	
  if(init < 0){
    mpfr_clear(wls);
    return;
  }
  if(init == 1) mpfr_init(wls);
  
  mpc_init2(prop_zgrnd,P);
  mpc_init2(r,P);
  mpc_init2(tmpc,P);
  mpc_set_fr_fr(prop_zgrnd,prop.zgndreal,prop.zgndimag,R);
  mpfr_inits(s,sps,q,d,tmp,tmp2, NULL);
  mpfr_set(d,i0,R);

	if (mpfr_cmp_d(d,0.0) == 0)
	{
    mpfr_set_ui(wls,10e3,R);
    mymax(wls,wls,propa.dlsa);
    mpfr_div(wls,prop.dh,wls,R);
    mpfr_mul(wls,prop.wn,wls,R);
    mpfr_add_d(wls,wls,0.021,R);
    mpfr_d_div(wls,0.021,wls,R);
		//wls=0.021/(0.021+prop.wn*prop.dh/mymax(10e3,propa.dlsa));
    mpfr_set_ui(alosv,0,R);
		//alosv=0.0;
	}
	else
	{
    mpfr_neg(q,d,R);
    mpfr_div_ui(q,q,50e3,R);
    mpfr_exp(q,q,R);
    mpfr_mul_d(q,q,0.8,R);
    mpfr_d_sub(q,1.0,q,R);
    mpfr_mul(q,q,prop.dh,R);
		//q=(1.0-0.8*exp(-d/50e3))*prop.dh;
    mpfr_div_d(s,q,16.0,R);
    mpfr_pow_uiui(s,s,1,4);
    mpfr_neg(s,s,R);
    mpfr_exp(s,s,R);
    mpfr_mul(s,s,q,R);
    mpfr_mul_d(s,s,0.78,R);
		//s=0.78*q*exp(-pow(q/16.0,0.25));
    mpfr_add(q,prop.he[0],prop.he[1],R);
		//q=prop.he[0]+prop.he[1];
    mpfr_mul(tmp,d,d,R);
    mpfr_mul(sps,q,q,R);
    mpfr_add(tmp,tmp,sps,R);
    mpfr_sqrt(tmp,tmp,R);
    mpfr_div(sps,q,tmp,R);
		//sps=q/sqrt(d*d+q*q);
    mpfr_mul(tmp,prop.wn,s,R);
    mpfr_mul(tmp,tmp,sps,R);
    mpfr_set_ui(tmp2,10,R);
    mymin(tmp,tmp2,tmp);
    mpfr_neg(tmp,tmp,R);
    mpfr_exp(tmp,tmp,R); // tmp = exp(-mymin(10.0,prop.wn*s*sps))
    
    mpc_fr_sub(r,sps,prop_zgrnd,R);
    mpc_add_fr(tmpc,prop_zgrnd,sps,R);
    mpc_div(r,r,tmpc,R);
    mpc_mul_fr(r,r,tmp,R);
		//r=(sps-prop_zgnd)/(sps+prop_zgnd)*exp(-mymin(10.0,prop.wn*s*sps));
    
		abq_alos(q,r);
    if(VERBOSE) mpfr_fprintf(stderr,"ALOS: q = %Rf\n",q);

		if (mpfr_cmp_d(q,0.25)<0 || mpfr_cmp(q,sps)<0){
      mpfr_div(tmp,sps,q,R);
      mpfr_sqrt(tmp,tmp,R);
      mpc_mul_fr(r,r,tmp,R);
			//r=r*sqrt(sps/q);
    }

    mpfr_mul(alosv,propa.emd,d,R);
    mpfr_add(alosv,alosv,propa.aed,R);
		//alosv=propa.emd*d+propa.aed;
    
    mpfr_mul(q,prop.wn,prop.he[0],R);
    mpfr_mul(q,q,prop.he[1],R);
    mpfr_mul_ui(q,q,2,R);
    mpfr_div(q,q,d,R);
		//q=prop.wn*prop.he[0]*prop.he[1]*2.0/d;

		if (mpfr_cmp_d(q,1.57) > 0){
      mpfr_d_div(q,2.4649,q,R);
      mpfr_d_sub(q,3.14,q,R);
			//q=3.14-2.4649/q;
    }

    //mpfr_sin_cos(tmp,tmp2,q,R);
    mpfr_sin(tmp,q,R);
    mpfr_cos(tmp2,q,R);
    mpfr_neg(tmp,tmp,R);
    mpc_set_fr_fr(tmpc,tmp2,tmp,R);
    mpc_add(tmpc,tmpc,r,R);
    abq_alos(tmp,tmpc);
    if(VERBOSE) mpfr_fprintf(stderr,"ALOS: q = %Rf, tmp = %Rf\n",q,tmp);
    mpfr_log(tmp,tmp,R); // tmp = log(abq_alos(complex<double>(cos(q),-sin(q))+r))
    mpfr_mul_d(tmp,tmp,-4.343,R);
    mpfr_sub(tmp,tmp,alosv,R); // tmp = (-4.343*log(abq_alos(complex<double>(cos(q),-sin(q))+r))-alosv)
    mpfr_mul(tmp,tmp,wls,R);
    mpfr_add(alosv,tmp,alosv,R);
		//alosv=(-4.343*log(abq_alos(complex<double>(cos(q),-sin(q))+r))-alosv)*wls+alosv;
	 }
   
   mpfr_clears(s, sps, q, d, tmp, tmp2,NULL);
   mpc_clear(prop_zgrnd);
   mpc_clear(r);
   mpc_clear(tmpc);
}


void lrprop (const mpfr_t i0, prop_type &prop, propa_type &propa, int init)  // PaulM_lrprop
{
  mpfr_t d, a0, a1, a2, a3, a4, a5, a6;
	mpfr_t d0, d1, d2, d3, d4, d5, d6, q,tmp,tmp2,tmp3;
  static bool wlos, wscat;
	static mpfr_t dmin, xae;
  bool wq;
	int j;
  mpc_t prop_zgrnd;
  
  if(init < 0){
    mpfr_clears(dmin, xae,NULL);
    return;
  }
  if(init == 1) mpfr_inits(dmin, xae, NULL);
  
  mpc_init2(prop_zgrnd,P);
  mpc_set_fr_fr(prop_zgrnd,prop.zgndreal,prop.zgndimag,R);
  
  mpfr_inits(d,a0, a1, a2, a3, a4, a5, a6,  d0, d1, d2, d3, d4, d5, d6, q,tmp, tmp2,tmp3,NULL);
  mpfr_set(d,i0,R);
	
	if (prop.mdp!=0)
	{
		for (j=0; j<2; j++){ 
      mpfr_mul_ui(propa.dls[j],prop.he[j],2,R);
      mpfr_div(propa.dls[j],propa.dls[j],prop.gme,R);
      mpfr_sqrt(propa.dls[j],propa.dls[j],R);
			//propa.dls[j]=sqrt(2.0*prop.he[j]/prop.gme);
      if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: dls0 = %Rf, dls1 = %Rf, gme = %Rf, he0 = %Rf, he1 = %Rf\n",propa.dls[0],propa.dls[1],prop.gme,prop.he[0],prop.he[1]);
    }

    mpfr_add(propa.dlsa,propa.dls[0],propa.dls[1],R);
		//propa.dlsa=propa.dls[0]+propa.dls[1];
    mpfr_add(propa.dla,prop.dl[0],prop.dl[1],R);
    if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: propa.dla = %Rf, prop.dl[0] = %Rf, prop.dl[1] = %Rf\n",propa.dla,prop.dl[0],prop.dl[1]);
		//propa.dla=prop.dl[0]+prop.dl[1];
    mpfr_add(tmp,prop.the[0],prop.the[1],R);
    mpfr_neg(propa.tha,propa.dla,R);
    mpfr_mul(propa.tha,propa.tha,prop.gme,R);
    mymax(propa.tha,propa.tha,tmp);
		//propa.tha=mymax(prop.the[0]+prop.the[1],-propa.dla*prop.gme);
		wlos=false;
		wscat=false;

		if (mpfr_cmp_d(prop.wn,0.838)<0 || mpfr_cmp_d(prop.wn,210.0)>0)
			prop.kwx=mymax(prop.kwx,ITM_CAUTION);

		for (j=0; j<2; j++){
			if (mpfr_cmp_d(prop.hg[j],1.0)<0 || mpfr_cmp_d(prop.hg[j],1000.0)>0){
				prop.kwx=mymax(prop.kwx,ITM_CAUTION);
      }
    }

    for (j=0; j<2; j++){
      mpfr_mul_d(tmp,propa.dls[j],0.1,R);
      mpfr_mul_ui(tmp2,propa.dls[j],3,R);
      if (mpfr_cmp_d(prop.the[j],200e-3)>0 || mpfr_cmp_d(prop.the[j],-200e-3)<0 || mpfr_cmp(prop.dl[j],tmp)<0 || mpfr_cmp(prop.dl[j],tmp2)>0){
        if(VERBOSE) mpfr_fprintf(stderr,"INVALID: the%d = %Rf > 200e-3, dl%d = %Rf < 0.1*dls%d = %Rf, dl%d > 3.0*dls%d = %Rf\n",j,prop.the[j],j,prop.dl[j],j,tmp,j,j,tmp2);
				prop.kwx=mymax(prop.kwx,ITM_INVALID);
      }
    }

    mpc_real(tmp,prop_zgrnd,R);
    mpc_imag(tmp2,prop_zgrnd,R); // tmp = prop_zgnd.real()
    mpfr_abs(tmp2,tmp2,R); // tmp2 = abs(prop_zgnd.imag())
    if (mpfr_cmp_d(prop.ens,250.0)<0 || mpfr_cmp_d(prop.ens,400.0)>0 || 
        mpfr_cmp_d(prop.gme,75e-9)<0 || mpfr_cmp_d(prop.gme,250e-9)>0 || 
        mpfr_cmp(tmp,tmp2)<=0 || mpfr_cmp_d(prop.wn,0.419)<0 || 
        mpfr_cmp_d(prop.wn,420.0)>0){
		  prop.kwx=ITM_REALLY_INVALID;
    }

		for (j=0; j<2; j++){
		  if (mpfr_cmp_d(prop.hg[j],0.5)<0 || mpfr_cmp_d(prop.hg[j],3000.0)>0){
			  prop.kwx=ITM_REALLY_INVALID;
		  }
    }

    mpfr_sub(dmin,prop.he[0],prop.he[1],R);
    mpfr_abs(dmin,dmin,R);
    mpfr_div_d(dmin,dmin,200e-3,R);
		//dmin=abs(prop.he[0]-prop.he[1])/200e-3;
    mpfr_set_ui(tmp,0,R); // setup
    adiff(q,tmp,prop,propa,1);
		//q=adiff(0.0,prop,propa);
		/* xae=pow(prop.wn*pow(prop.gme,2),-THIRD); */
    mpfr_mul(xae,prop.wn,prop.gme,R);
    mpfr_mul(xae,xae,prop.gme,R);
    mpfr_pow_sisi(xae,xae,-1,3);
		//xae=pow(prop.wn*prop.gme*prop.gme,-THIRD);
    mpfr_mul_d(tmp,xae,1.3787,R);
    mpfr_add(tmp,tmp,propa.dla,R);
    mymax(d3,tmp,propa.dlsa);
		//d3=mymax(propa.dlsa,1.3787*xae+propa.dla);
    mpfr_mul_d(d4,xae,2.7574,R);
    mpfr_add(d4,d4,d3,R);
		//d4=d3+2.7574*xae;
		adiff(a3,d3,prop,propa,0);
		adiff(a4,d4,prop,propa,0);
    adiff(a4,d4,prop,propa,-1); // cleanup statics
    mpfr_sub(tmp,a4,a3,R);
    mpfr_sub(tmp2,d4,d3,R);
    mpfr_div(propa.emd,tmp,tmp2,R);
		//propa.emd=(a4-a3)/(d4-d3);
    mpfr_mul(propa.aed,propa.emd,d3,R);
    mpfr_sub(propa.aed,a3,propa.aed,R);
		//propa.aed=a3-propa.emd*d3;
    if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: a3 = %Rf, a4 = %Rf, d4 = %Rf, d3 = %Rf\n",a3,a4,d4,d3);
	}

	if (prop.mdp>=0)
	{
		prop.mdp=0;
		mpfr_set(prop.dist,d,R);;
	}

	if (mpfr_cmp_d(prop.dist,0.0)>0)
	{
		if (mpfr_cmp_d(prop.dist,1000e3)>0)
			prop.kwx=mymax(prop.kwx,ITM_CAUTION);

		if (mpfr_cmp(prop.dist,dmin)<0){
      if(VERBOSE) mpfr_fprintf(stderr,"INVALID: dist = %Rf < dmin = %Rf\n",prop.dist,dmin); 
			prop.kwx=mymax(prop.kwx,ITM_INVALID);
    }

		if (mpfr_cmp_d(prop.dist,1e3)<0 || mpfr_cmp_d(prop.dist,2000e3)>0)
			prop.kwx=ITM_REALLY_INVALID;
	}

	if (mpfr_cmp(prop.dist,propa.dlsa)<0)
	{
		if (!wlos)
		{
      mpfr_set_ui(tmp,0,R);
			alos(q,tmp,prop,propa,1);
			mpfr_set(d2,propa.dlsa,R);
      mpfr_mul(a2,d2,propa.emd,R);
      mpfr_add(a2,propa.aed,a2,R);
      if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: a2 = %Rf, propa.aed = %Rf, propa.emd = %Rf\n",a2,propa.aed,propa.emd);
			//a2=propa.aed+d2*propa.emd;
      mpfr_mul_d(d0,prop.wn,1.908,R);
      mpfr_mul(d0,d0,prop.he[0],R);
      mpfr_mul(d0,d0,prop.he[1],R);
			//d0=1.908*prop.wn*prop.he[0]*prop.he[1];

			if (mpfr_cmp_d(propa.aed,0.0)>=0)
			{
        mpfr_mul_d(tmp,propa.dla,0.5,R);
				//d0=mymin(d0,0.5*propa.dla);
        mymin(d0,d0,tmp);
        mpfr_sub(d1,propa.dla,d0,R);
        mpfr_mul_d(d1,d1,0.25,R);
        mpfr_add(d1,d1,d0,R);
				//d1=d0+0.25*(propa.dla-d0);
			}

			else{
        mpfr_neg(tmp,propa.aed,R);
        mpfr_div(tmp,tmp,propa.emd,R);
        mpfr_mul_d(tmp2,propa.dla,0.25,R);
        mymax(d1,tmp,tmp2);
				//d1=mymax(-propa.aed/propa.emd,0.25*propa.dla);
      }

			alos(a1,d1,prop,propa,0);
			wq=false;

			if (mpfr_cmp(d0,d1)<0)
			{
				alos(a0,d0,prop,propa,0);
        mpfr_div(q,d2,d0,R);
        mpfr_log(q,q,R);
				//q=log(d2/d0);
        
        mpfr_sub(tmp,d2,d0,R);
        mpfr_sub(tmp2,a1,a0,R);
        mpfr_mul(tmp,tmp,tmp2,R);
        mpfr_sub(tmp2,d1,d0,R);
        mpfr_sub(tmp3,a2,a0,R);
        mpfr_mul(tmp2,tmp2,tmp3,R);
        mpfr_sub(tmp,tmp,tmp2,R); // tmp = (d2-d0)*(a1-a0) - (d1-d0)*(a2-a0)
        if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: numerator = %Rf, a1 = %Rf, a0 = %Rf, a2 = %Rf\n",tmp,a1,a0,a2);
        mpfr_sub(tmp2,d2,d0,R);
        mpfr_div(tmp3,d1,d0,R);
        mpfr_log(tmp3,tmp3,R);
        mpfr_mul(tmp2,tmp2,tmp3,R);
        mpfr_sub(tmp3,d1,d0,R);
        mpfr_mul(tmp3,tmp3,q,R);
        mpfr_sub(tmp2,tmp2,tmp3,R); // tmp2 = (d2-d0)*log(d1/d0) - (d1-d0)*q
        if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: denomenator = %Rf\n",tmp2);
        mpfr_div(tmp,tmp,tmp2,R);
                
        mpfr_set_ui(tmp2,0,R);
        mymax(propa.ak2,tmp,tmp2);
        if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: d2 = %Rf, d1 = %Rf, d0 = %Rf, q = %Rf, propa.ak2 = %Rf, tmp = %Rf, tmp2 = %Rf\n",d2,d1,d0,q,propa.ak2,tmp,tmp2);
				//propa.ak2=mymax(0.0,((d2-d0)*(a1-a0) - (d1-d0)*(a2-a0)) / ((d2-d0)*log(d1/d0) - (d1-d0)*q));
        
				wq=mpfr_cmp_d(propa.aed,0.0)>=0 || mpfr_cmp_d(propa.ak2,0.0)>0;

				if (wq)
				{ 
          mpfr_sub(tmp,d2,d0,R);
          mpfr_mul(tmp2,propa.ak2,q,R);
          mpfr_add(tmp2,a0,tmp2,R); // tmp2 = a0 + propa.ak2*q
          mpfr_sub(tmp2,a2,tmp2,R); // tmp2 = a2 - (a0 + propa.ak2*q) 
          mpfr_div(propa.ak1,tmp2,tmp,R);
          if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: propa.ak1 = %Rf, a2 = %Rf, a0 = %Rf, d2 = %Rf, d0 = %Rf\n",propa.ak1,a2,a0,d2,d0); 
					//propa.ak1=(a2-a0-propa.ak2*q)/(d2-d0);

					if (mpfr_cmp_d(propa.ak1,0.0)<0)
					{
						mpfr_set_ui(propa.ak1,0,R);
            
            FORTRAN_DIM(propa.ak2,a2,a0);
            mpfr_div(propa.ak2,propa.ak2,q,R);

						if (mpfr_cmp_d(propa.ak2,0.0) == 0)
							mpfr_set(propa.ak1,propa.emd,R);
					}
				}
			}
      
      alos(a1,d1,prop,propa,-1); // cleanup statics

			if (!wq)
			{
        FORTRAN_DIM(propa.ak1,a2,a1);
        mpfr_sub(tmp,d2,d1,R);
        mpfr_div(propa.ak1,propa.ak1,tmp,R);
				//propa.ak1=FORTRAN_DIM(a2,a1)/(d2-d1);
        mpfr_set_ui(propa.ak2,0,R);
				//propa.ak2=0.0;

				if (mpfr_cmp_d(propa.ak1,0.0) == 0)
					mpfr_set(propa.ak1,propa.emd,R);
			}

      // note that:
      // a - b - c == a - (b + c)
      // but
      // a - b - c != a - (b - c)
      mpfr_log(tmp,d2,R);
      mpfr_mul(tmp,propa.ak2,tmp,R); // tmp = propa.ak2*log(d2)
      mpfr_mul(tmp2,propa.ak1,d2,R); // tmp2 = propa.ak1*d2
      mpfr_add(tmp,tmp2,tmp,R); 
      mpfr_sub(propa.ael,a2,tmp,R);
      if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: d2 = %Rf, propa.ael = %Rf, propa.ak1 = %Rf, prop.dist = %Rf, propa.ak2 = %Rf\n",d2,propa.ael,propa.ak1,prop.dist,propa.ak2);
			//propa.ael=a2-propa.ak1*d2-propa.ak2*log(d2);
			wlos=true;
		}

		if (mpfr_cmp_d(prop.dist,0.0)>0){
      mpfr_log(tmp,prop.dist,R);
      mpfr_mul(tmp,tmp,propa.ak2,R);
      mpfr_mul(tmp2,propa.ak1,prop.dist,R);
      mpfr_add(tmp,tmp,tmp2,R);
      mpfr_add(prop.aref,propa.ael,tmp,R);
      if(VERBOSE) mpfr_fprintf(stderr,"LRPROP: prop.aref = %Rf, propa.ael = %Rf, propa.ak1 = %Rf, prop.dist = %Rf, propa.ak2 = %Rf\n",prop.aref,propa.ael,propa.ak1,prop.dist,propa.ak2);
			//prop.aref=propa.ael+propa.ak1*prop.dist+propa.ak2*log(prop.dist);
    }
	}

	if (mpfr_cmp_d(prop.dist,0.0)<=0 || mpfr_cmp(prop.dist,propa.dlsa)>=0)
	{
		if (!wscat)
		{ 
      mpfr_set_ui(tmp,0,R);
			ascat(q,tmp,prop,propa,1);
      mpfr_add_ui(d5,propa.dla,200e3,R);
			//d5=propa.dla+200e3;
      mpfr_add_ui(d6,d5,200e3,R);
			//d6=d5+200e3;
			ascat(a6,d6,prop,propa,0);
			ascat(a5,d5,prop,propa,0);
      ascat(a5,d5,prop,propa,-1); // cleanup statics

			if (mpfr_cmp_d(a5,1000.0)<0)
			{
        mpfr_sub(propa.ems,a6,a5,R);
        mpfr_div_ui(propa.ems,propa.ems,200e3,R);
				//propa.ems=(a6-a5)/200e3;
        
        mpfr_mul_d(tmp,prop.wn,47.7,R);
        mpfr_log(tmp,tmp,R);
        mpfr_mul(tmp,tmp,xae,R);
        mpfr_mul_d(tmp,tmp,0.3,R);
        mpfr_add(tmp,tmp,propa.dla,R); // tmp = propa.dla+0.3*xae*log(47.7*prop.wn)
        mpfr_sub(tmp2,propa.emd,propa.ems,R);
        mpfr_mul(propa.dx,propa.ems,d5,R); // prop.dx = (propa.emd-propa.ems)
        
        mpfr_mul(tmp2,propa.ems,d5,R);
        mpfr_add(tmp2,tmp2,propa.aed,R);
        mpfr_sub(tmp2,a5,tmp2,R); // tmp2 = (a5-propa.aed-propa.ems*d5)
        
        mpfr_div(tmp2,tmp2,propa.dx,R);
        mymax(propa.dx,tmp,tmp2);
        mymax(propa.dx,propa.dlsa,propa.dx);
				//propa.dx=mymax(propa.dlsa,mymax(propa.dla+0.3*xae*log(47.7*prop.wn),(a5-propa.aed-propa.ems*d5)/(propa.emd-propa.ems)));

        mpfr_sub(tmp,propa.emd,propa.ems,R);
        mpfr_mul(tmp,tmp,propa.dx,R);
        mpfr_add(propa.aes,tmp,propa.aed,R);
				//propa.aes=(propa.emd-propa.ems)*propa.dx+propa.aed;
			}

			else
			{
				mpfr_set(propa.ems,propa.emd,R);
				mpfr_set(propa.aes,propa.aed,R);
				mpfr_set_ui(propa.dx,10e6,R);
			}

			wscat=true;
		}

		if (mpfr_cmp(prop.dist,propa.dx)>0){
      mpfr_mul(prop.aref,propa.ems,prop.dist,R);
      mpfr_add(prop.aref,propa.aes,prop.aref,R);
			//prop.aref=propa.aes+propa.ems*prop.dist;
    }
    else
    {
      mpfr_mul(prop.aref,propa.ems,prop.dist,R);
      mpfr_add(prop.aref,propa.aed,prop.aref,R);
			//prop.aref=propa.aed+propa.emd*prop.dist;
    }
	}
  mpfr_set_ui(tmp,0,R);
  mymax(prop.aref,tmp,prop.aref);
  mpfr_clears(d,a0, a1, a2, a3, a4, a5, a6,  d0, d1, d2, d3, d4, d5, d6, q,tmp, tmp2,NULL);
}

void curve (mpfr_t r, mpfr_t const i0, mpfr_t const i1, mpfr_t const i2, mpfr_t const i3, mpfr_t const i4, mpfr_t const i5)
{
	/* return (c1+c2/(1.0+pow((de-x2)/x3,2.0)))*pow(de/x1,2.0)/(1.0+pow(de/x1,2.0)); */

	mpfr_t temp1, temp2, c1, c2, x1, x2, x3, de;
  mpfr_inits(temp1, temp2, c1, c2, x1, x2, x3, de,NULL);
  mpfr_set(c1,i0,R);
  mpfr_set(c2,i1,R);
  mpfr_set(x1,i2,R);
  mpfr_set(x2,i3,R);
  mpfr_set(x3,i4,R);
  mpfr_set(de,i5,R);

  mpfr_sub(temp1,de,x2,R);
  mpfr_div(temp1,temp1,x3,R);
	//temp1=(de-x2)/x3;
  mpfr_div(temp2,de,x1,R);
	//temp2=de/x1;

  mpfr_mul(temp1,temp1,temp1,R);
	//temp1*=temp1;
  mpfr_mul(temp2,temp2,temp2,R);
	//temp2*=temp2;
  
  
  mpfr_add_ui(r,temp1,1,R);
  mpfr_div(r,c2,r,R);
  mpfr_add(r,c1,r,R);
  mpfr_mul(r,r,temp2,R);
  mpfr_add_ui(temp2,temp2,1,R);
  mpfr_div(r,r,temp2,R);
  
  mpfr_clears(temp1, temp2, c1, c2, x1, x2, x3, de,NULL);
}

// init = 1 => initialize
// init = 0 => normal
// init = -1 => cleanup
void avar(mpfr_t avarv, const mpfr_t i0, const mpfr_t i1, const mpfr_t i2,prop_type &prop, propv_type &propv, int init)
{
	static int kdv;
	static mpfr_t dexa, de, vmd, vs0, sgl, sgtm, sgtp, sgtd, tgtd, gm, gp, 
  cv1, cv2, yv1, yv2, yv3, csm1, csm2, ysm1, ysm2, ysm3, csp1, csp2, ysp1, 
  ysp2, ysp3, csd1, zd, cfm1, cfm2, cfm3, cfp1, cfp2, cfp3;
  mpfr_t rt, rl, q, vs, zt, zl, zc, sgt, yr, zzt, zzl, zzc, tmp, tmp2;

	double bv1[7]={-9.67,-0.62,1.26,-9.21,-0.62,-0.39,3.15};
	double bv2[7]={12.7,9.19,15.5,9.05,9.19,2.86,857.9};
	double xv1[7]={144.9e3,228.9e3,262.6e3,84.1e3,228.9e3,141.7e3,2222.e3};
	double xv2[7]={190.3e3,205.2e3,185.2e3,101.1e3,205.2e3,315.9e3,164.8e3};
	double xv3[7]={133.8e3,143.6e3,99.8e3,98.6e3,143.6e3,167.4e3,116.3e3};
	double bsm1[7]={2.13,2.66,6.11,1.98,2.68,6.86,8.51};
	double bsm2[7]={159.5,7.67,6.65,13.11,7.16,10.38,169.8};
	double xsm1[7]={762.2e3,100.4e3,138.2e3,139.1e3,93.7e3,187.8e3,609.8e3};
	double xsm2[7]={123.6e3,172.5e3,242.2e3,132.7e3,186.8e3,169.6e3,119.9e3};
	double xsm3[7]={94.5e3,136.4e3,178.6e3,193.5e3,133.5e3,108.9e3,106.6e3};
	double bsp1[7]={2.11,6.87,10.08,3.68,4.75,8.58,8.43};
	double bsp2[7]={102.3,15.53,9.60,159.3,8.12,13.97,8.19};
	double xsp1[7]={636.9e3,138.7e3,165.3e3,464.4e3,93.2e3,216.0e3,136.2e3};
	double xsp2[7]={134.8e3,143.7e3,225.7e3,93.1e3,135.9e3,152.0e3,188.5e3};
	double xsp3[7]={95.6e3,98.6e3,129.7e3,94.2e3,113.4e3,122.7e3,122.9e3};
	double bsd1[7]={1.224,0.801,1.380,1.000,1.224,1.518,1.518};
	double bzd1[7]={1.282,2.161,1.282,20.,1.282,1.282,1.282};
	double bfm1[7]={1.0,1.0,1.0,1.0,0.92,1.0,1.0};
	double bfm2[7]={0.0,0.0,0.0,0.0,0.25,0.0,0.0};
	double bfm3[7]={0.0,0.0,0.0,0.0,1.77,0.0,0.0};
	double bfp1[7]={1.0,0.93,1.0,0.93,0.93,1.0,1.0};
	double bfp2[7]={0.0,0.31,0.0,0.19,0.31,0.0,0.0};
	double bfp3[7]={0.0,2.00,0.0,1.79,2.00,0.0,0.0};
  
	static bool ws, w1;
  
  if(init < 0){
    mpfr_clears(dexa, de, vmd, vs0, sgl, sgtm, sgtp, sgtd, tgtd, gm, gp, 
      cv1, cv2, yv1, yv2, yv3, csm1, csm2, ysm1, ysm2, ysm3, csp1, csp2, ysp1, 
      ysp2, ysp3, csd1, zd, cfm1, cfm2, cfm3, cfp1, cfp2, cfp3, NULL);
    return;
  }
  
  mpfr_inits(rt, rl, avarv, q, vs, zt, zl, zc, sgt, yr,tmp,tmp2,zzt,zzc,zzl,NULL);
  mpfr_set_d(rt,7.8,R);
  mpfr_set_d(rl,24.0,R);
  mpfr_set(zzt,i0,R);
  mpfr_set(zzl,i1,R);
  mpfr_set(zzc,i2,R);
  
  // only do init the first time we're run...
  if(init == 1){
    mpfr_inits(dexa, de, vmd, vs0, sgl, sgtm, sgtp, sgtd, tgtd, gm, gp, 
      cv1, cv2, yv1, yv2, yv3, csm1, csm2, ysm1, ysm2, ysm3, csp1, csp2, ysp1, 
      ysp2, ysp3, csd1, zd, cfm1, cfm2, cfm3, cfp1, cfp2, cfp3, NULL);
  }
  
	int temp_klim=propv.klim-1;

	if (propv.lvar>0)
	{
		switch (propv.lvar)
		{
			default:
			if (propv.klim<=0 || propv.klim>7)
			{
				propv.klim = 5;
				temp_klim = 4;
				prop.kwx=mymax(prop.kwx,ITM_DEFAULTS);
			}

			mpfr_set_d(cv1,bv1[temp_klim],R);
			mpfr_set_d(cv2,bv2[temp_klim],R);
			mpfr_set_d(yv1,xv1[temp_klim],R);
			mpfr_set_d(yv2,xv2[temp_klim],R);
			mpfr_set_d(yv3,xv3[temp_klim],R);
			mpfr_set_d(csm1,bsm1[temp_klim],R);
			mpfr_set_d(csm2,bsm2[temp_klim],R);
			mpfr_set_d(ysm1,xsm1[temp_klim],R);
			mpfr_set_d(ysm2,xsm2[temp_klim],R);
			mpfr_set_d(ysm3,xsm3[temp_klim],R);
			mpfr_set_d(csp1,bsp1[temp_klim],R);
			mpfr_set_d(csp2,bsp2[temp_klim],R);
			mpfr_set_d(ysp1,xsp1[temp_klim],R);
			mpfr_set_d(ysp2,xsp2[temp_klim],R);
			mpfr_set_d(ysp3,xsp3[temp_klim],R);
			mpfr_set_d(csd1,bsd1[temp_klim],R);
			mpfr_set_d(zd,bzd1[temp_klim],R);
			mpfr_set_d(cfm1,bfm1[temp_klim],R);
			mpfr_set_d(cfm2,bfm2[temp_klim],R);
			mpfr_set_d(cfm3,bfm3[temp_klim],R);
			mpfr_set_d(cfp1,bfp1[temp_klim],R);
			mpfr_set_d(cfp2,bfp2[temp_klim],R);
			mpfr_set_d(cfp3,bfp3[temp_klim],R);

			case 4:
			kdv=propv.mdvar;
			ws=kdv>=20;

			if (ws)
				kdv-=20;

			w1=kdv>=10;

			if (w1)
				kdv-=10;

			if (kdv<0 || kdv>3)
			{
				kdv=0;
				prop.kwx=mymax(prop.kwx,ITM_DEFAULTS);
			}

			case 3:
      mpfr_mul_d(q,prop.wn,0.133,R);
      mpfr_log(q,q,R);
			//q=log(0.133*prop.wn);

			/* gm=cfm1+cfm2/(pow(cfm3*q,2.0)+1.0); */
			/* gp=cfp1+cfp2/(pow(cfp3*q,2.0)+1.0); */

      mpfr_mul(gm,cfm3,q,R);
      mpfr_mul(gm,gm,cfm3,R);
      mpfr_mul(gm,gm,q,R);
      mpfr_add_ui(gm,gm,1,R);
      mpfr_div(gm,cfm2,gm,R);
      mpfr_add(gm,gm,cfm1,R);
			//gm=cfm1+cfm2/((cfm3*q*cfm3*q)+1.0);
      mpfr_mul(gp,cfp3,q,R);
      mpfr_mul(gp,gp,cfp3,R);
      mpfr_mul(gp,gp,q,R);
      mpfr_add_ui(gp,gp,1,R);
      mpfr_div(gp,cfp2,gp,R);
      mpfr_add(gp,gp,cfp1,R);
			//gp=cfp1+cfp2/((cfp3*q*cfp3*q)+1.0);

			case 2:
      mpfr_mul_ui(tmp,prop.he[1],18e6,R);
      mpfr_sqrt(tmp,tmp,R);
      mpfr_mul_ui(tmp2,prop.he[0],18e6,R);
      mpfr_sqrt(tmp2,tmp2,R);
      mpfr_add(tmp,tmp,tmp2,R); // tmp = sqrt(18e6*prop.he[0])+sqrt(18e6*prop.he[1])
      mpfr_d_div(tmp2,575.7e12,prop.wn,R);
      mpfr_pow_uiui(tmp2,tmp2,1,3);
      mpfr_add(dexa,tmp,tmp2,R);
			//dexa=sqrt(18e6*prop.he[0])+sqrt(18e6*prop.he[1])+pow((575.7e12/prop.wn),THIRD);

			case 1:
      if (mpfr_cmp(prop.dist,dexa)<0){
        mpfr_mul_ui(de,prop.dist,130e3,R);
        mpfr_div(de,de,dexa,R);
				//de=130e3*prop.dist/dexa;
      }else{
        mpfr_add_ui(de,prop.dist,130e3,R);
        mpfr_sub(de,de,dexa,R);
				//de=130e3+prop.dist-dexa;
      }
		}

		curve(vmd,cv1,cv2,yv1,yv2,yv3,de);
		curve(sgtm,csm1,csm2,ysm1,ysm2,ysm3,de);
    mpfr_mul(sgtm,sgtm,gm,R);
		curve(sgtp,csp1,csp2,ysp1,ysp2,ysp3,de);
    mpfr_mul(sgtp,sgtp,gp,R);
    mpfr_mul(sgtd,sgtp,csd1,R);
		//sgtd=sgtp*csd1;
    mpfr_sub(tgtd,sgtp,sgtd,R);
    mpfr_mul(tgtd,tgtd,zd,R);
		//tgtd=(sgtp-sgtd)*zd;

		if (w1)	mpfr_set_ui(sgl,0,R);
		else
		{
      mpfr_neg(q,prop.dist,R);
      mpfr_div_ui(q,q,50e3,R);
      mpfr_exp(q,q,R);
      mpfr_mul_d(q,q,0.8,R);
      mpfr_d_sub(q,1.0,q,R); // q = (1.0-0.8*exp(-prop.dist/50e3))
      mpfr_mul(q,q,prop.dh,R);
      mpfr_mul(q,q,prop.wn,R);
			//q=(1.0-0.8*exp(-prop.dist/50e3))*prop.dh*prop.wn;
      mpfr_mul_ui(sgl,q,10,R);
      mpfr_add_ui(tmp,q,13,R);
      mpfr_div(sgl,sgl,tmp,R);
			//sgl=10.0*q/(q+13.0);
		}

		if (ws) mpfr_set_ui(vs0,0,R);
		else
		{
			/* vs0=pow(5.0+3.0*exp(-de/100e3),2.0); */
      mpfr_neg(vs0,de,R);
      mpfr_div_ui(vs0,vs0,100e3,R);
      mpfr_exp(vs0,vs0,R);
      mpfr_mul_ui(vs0,vs0,3,R);
      mpfr_add_ui(vs0,vs0,5,R);
			//vs0=(5.0+3.0*exp(-de/100e3));
      mpfr_mul(vs0,vs0,vs0,R);
			//vs0*=vs0;
		}
		propv.lvar=0;
	}

	mpfr_set(zt,zzt,R);
	mpfr_set(zl,zzl,R);
	mpfr_set(zc,zzc,R);

	switch (kdv)
	{
		case 0:
		mpfr_set(zt,zc,R);
		mpfr_set(zl,zc,R);
		break;

		case 1:
		mpfr_set(zl,zc,R);
		break;

		case 2:
		mpfr_set(zl,zt,R);
	}

	if (mpfr_cmp_d(zt,3.1)>0 || mpfr_cmp_d(zt,-3.1)<0 || mpfr_cmp_d(zl,3.1)>0 || 
    mpfr_cmp_d(zl,-3.1)<0 || mpfr_cmp_d(zc,3.1)>0 || mpfr_cmp_d(zc,-3.1)<0)
		prop.kwx=mymax(prop.kwx,ITM_CAUTION);

	if (mpfr_cmp_d(zt,0.0)<0)
		mpfr_set(sgt,sgtm,R);
	else if (mpfr_cmp(zt,zd)<=0)
		mpfr_set(sgt,sgtp,R);
	else{
    mpfr_div(sgt,tgtd,zt,R);
    mpfr_add(sgt,sgt,sgtd,R);
		//sgt=sgtd+tgtd/zt;
  }

  mpfr_mul(tmp,sgt,zt,R);
  mpfr_mul(tmp,tmp,sgt,R);
  mpfr_mul(tmp,tmp,zt,R);
  mpfr_mul(tmp2,zc,zc,R);
  mpfr_add(tmp2,tmp2,rt,R);
  mpfr_div(tmp,tmp,tmp2,R);
  mpfr_add(tmp,tmp,vs0,R); // tmp = vs0 + (sgt*zt*sgt*zt)/(rt+zc*zc)
  mpfr_mul(tmp2,sgl,sgl,R);
  mpfr_mul(tmp2,tmp2,zl,R);
  mpfr_mul(tmp2,tmp2,zl,R);
  mpfr_mul(vs,zc,zc,R);
  mpfr_add(vs,vs,rl,R);
  mpfr_div(tmp2,tmp2,vs,R);
  mpfr_add(vs,tmp,tmp2,R);
  
	/* vs=vs0+pow(sgt*zt,2.0)/(rt+zc*zc)+pow(sgl*zl,2.0)/(rl+zc*zc); */
	//vs=vs0 + (sgt*zt*sgt*zt)/(rt+zc*zc) + (sgl*zl*sgl*zl)/(rl+zc*zc);
  

	if (kdv==0)
	{
		mpfr_set_ui(yr,0,R);
    mpfr_mul(tmp,sgt,sgt,R);
    mpfr_mul(tmp2,sgl,sgl,R);
    mpfr_add(tmp,tmp,tmp2,R);
    mpfr_add(tmp,tmp,vs,R);
    mpfr_sqrt(propv.sgc,tmp,R);
		//propv.sgc=sqrt(sgt*sgt+sgl*sgl+vs);
	}

	else if (kdv==1)
	{
		mpfr_mul(yr,sgt,zt,R);
    
    mpfr_mul(tmp,sgl,sgl,R);
    mpfr_add(tmp,tmp,vs,R);
    mpfr_sqrt(propv.sgc,tmp,R);
		//propv.sgc=sqrt(sgl*sgl+vs);
	}

	else if (kdv==2)
	{
    mpfr_mul(tmp,sgt,sgt,R);
    mpfr_mul(tmp2,sgl,sgl,R);
    mpfr_add(tmp,tmp,tmp2,R);
    mpfr_sqrt(tmp,tmp,R);
    mpfr_mul(yr,tmp,zt,R);
		//yr=sqrt(sgt*sgt+sgl*sgl)*zt;
    mpfr_sqrt(propv.sgc,vs,R);
		//propv.sgc=sqrt(vs);
	}

	else
	{
    mpfr_mul(tmp,sgt,zt,R);
    mpfr_mul(tmp2,sgl,zl,R);
    mpfr_add(yr,tmp,tmp2,R);
		//yr=sgt*zt+sgl*zl;
    mpfr_sqrt(propv.sgc,vs,R);
		//propv.sgc=sqrt(vs);
	}

  mpfr_mul(tmp,propv.sgc,zc,R);
  mpfr_add(tmp,tmp,yr,R);
  mpfr_add(tmp,tmp,vmd,R); 
  mpfr_sub(avarv,prop.aref,tmp,R);
  if(VERBOSE) mpfr_fprintf(stderr,"AVAR: avarv = %Rf, prop.aref = %Rf, vmd = %Rf, yr = %Rf, propv.sgc = %Rf, zc = %Rf, zzc = %Rf\n",avarv,prop.aref,vmd,yr,propv.sgc,zc,zzc);
	//avarv=prop.aref-vmd-yr-propv.sgc*zc;

	if (mpfr_cmp_d(avarv,0.0)<0){
    mpfr_mul_ui(tmp,avarv,10,R);
    mpfr_d_sub(tmp,29.0,tmp,R);
    mpfr_d_sub(tmp2,29.0,avarv,R);
    mpfr_mul(tmp2,tmp2,avarv,R);
    mpfr_div(avarv,tmp2,tmp,R);
		//avarv=avarv*(29.0-avarv)/(29.0-10.0*avarv);
  }
  
  mpfr_clears(rt, rl, q, vs, zt, zl, zc, sgt, yr, zzt, zzl, zzc, tmp, tmp2, NULL);
}

void hzns(const mpfr_t pfl[], prop_type &prop)
{
	bool wq;
	int np;
	mpfr_t xi, za, zb, qc, q, sb, sa,tmp;
  mpfr_inits(xi, za, zb, qc, q, sb, sa,tmp,NULL);

	np=mpfr_get_ui(pfl[0],R);
	mpfr_set(xi,pfl[1],R);
  mpfr_add(za,pfl[2],prop.hg[0],R);
	//za=pfl[2]+prop.hg[0];
  mpfr_add(zb,pfl[np+2],prop.hg[1],R);
	//zb=pfl[np+2]+prop.hg[1];
  mpfr_mul_d(qc,prop.gme,0.5,R);
	//qc=0.5*prop.gme;
  mpfr_mul(q,qc,prop.dist,R);
	//q=qc*prop.dist;
  mpfr_sub(tmp,zb,za,R);
  mpfr_div(prop.the[1],tmp,prop.dist,R);
	//prop.the[1]=(zb-za)/prop.dist;
  mpfr_sub(prop.the[0],prop.the[1],q,R);
	//prop.the[0]=prop.the[1]-q;
  mpfr_neg(tmp,prop.the[1],R);
  mpfr_sub(prop.the[1],tmp,q,R);
	//prop.the[1]=-prop.the[1]-q;
  mpfr_set(prop.dl[0],prop.dist,R);
	//prop.dl[0]=prop.dist;
  mpfr_set(prop.dl[1],prop.dist,R);
	//prop.dl[1]=prop.dist;
  
  if(VERBOSE) mpfr_fprintf(stderr,"HZNS: prop.dl[0] = %Rf, prop.dl[1] = %Rf, prop.dist = %Rf\n",prop.dl[0],prop.dl[1],prop.dist);

	if (np>=2)
	{
		mpfr_set_ui(sa,0.0,R);
		mpfr_set(sb,prop.dist,R);
		wq=true;

		for (int i=1; i<np; i++)
		{
			mpfr_add(sa,sa,xi,R);
			mpfr_sub(sb,sb,xi,R);
      
      mpfr_mul(tmp,qc,sa,R);
      mpfr_add(tmp,tmp,prop.the[0],R);
      mpfr_mul(tmp,tmp,sa,R);
      mpfr_add(tmp,tmp,za,R);
      mpfr_sub(q,pfl[i+2],tmp,R);
			//q=pfl[i+2]-(qc*sa+prop.the[0])*sa-za;

			if (mpfr_cmp_d(q,0.0)>0)
			{
        mpfr_div(tmp,q,sa,R);
        mpfr_add(prop.the[0],prop.the[0],tmp,R);
				//prop.the[0]+=q/sa;
        mpfr_set(prop.dl[0],sa,R);
				//prop.dl[0]=sa;
				wq=false;
			}
      
      if(VERBOSE) mpfr_fprintf(stderr,"HZNS: i = %d, prop.dl[0] = %Rf, prop.dl[1] = %Rf, prop.dist = %Rf\n",i,prop.dl[0],prop.dl[1],prop.dist);

			if (!wq)
			{
        mpfr_mul(tmp,qc,sb,R);
        mpfr_add(tmp,tmp,prop.the[1],R);
        mpfr_mul(tmp,tmp,sb,R);
        mpfr_add(tmp,tmp,zb,R);
        mpfr_sub(q,pfl[i+2],tmp,R);
				//q=pfl[i+2]-(qc*sb+prop.the[1])*sb-zb;

				if (mpfr_cmp_d(q,0.0)>0)
				{
          mpfr_div(tmp,q,sb,R);
          mpfr_add(prop.the[1],prop.the[1],tmp,R);
					//prop.the[1]+=q/sb;
          mpfr_set(prop.dl[1],sb,R);
					//prop.dl[1]=sb;
				}
			}
		}
	}
  
  mpfr_clears(xi, za, zb, qc, q, sb, sa,tmp,NULL);
}
  
// z0 and zn are output
void z1sq1 (const mpfr_t z[], const mpfr_t i0, const mpfr_t i1, mpfr_t z0, mpfr_t zn)
{
	mpfr_t xn, xa, xb, x, a, b, tmp,x1,x2;
	int n, ja, jb;

  mpfr_inits(xn, xa, xb, x, a, b, tmp,x1, x2,NULL);
  mpfr_set(x1,i0,R);
  mpfr_set(x2,i1,R);
  
	mpfr_set(xn,z[0],R);
  mpfr_div(tmp,x1,z[1],R);
  mpfr_set_ui(xa,0,R);
  FORTRAN_DIM(xa,tmp,xa);
  mpfr_floor(xa,xa);
	//xa=int(FORTRAN_DIM(x1/z[1],0.0));
  mpfr_div(tmp,x2,z[1],R);
  FORTRAN_DIM(xb,xn,tmp);
  mpfr_floor(xb,xb);
  mpfr_sub(xb,xn,xb,R);
	//xb=xn-int(FORTRAN_DIM(xn,x2/z[1]));
  
	if (mpfr_cmp(xb,xa)<=0)
	{
    mpfr_set_ui(tmp,1,R);
		FORTRAN_DIM(xa,xa,tmp);
    mpfr_add_ui(tmp,xb,1,R);
    FORTRAN_DIM(xb,xn,tmp);
    mpfr_sub(xb,xn,xb,R);
		//xb=xn-FORTRAN_DIM(xn,xb+1.0);
	}

	ja=mpfr_get_ui(xa,R);
	jb=mpfr_get_ui(xb,R);
  n=jb-ja;
  mpfr_sub(xa,xb,xa,R);
	//xa=xb-xa;
  mpfr_mul_d(x,xa,-0.5,R);
	//x=-0.5*xa;
  mpfr_add(xb,xb,x,R);
	//xb+=x;
  mpfr_add(a,z[ja+2],z[jb+2],R);
  mpfr_mul_d(a,a,0.5,R);
	//a=0.5*(z[ja+2]+z[jb+2]);
  mpfr_sub(b,z[ja+2],z[jb+2],R);
  mpfr_mul(b,b,x,R);
  mpfr_mul_d(b,b,0.5,R);
	//b=0.5*(z[ja+2]-z[jb+2])*x;

	for (int i=2; i<=n; ++i)
	{
		++ja;
    mpfr_add_ui(x,x,1,R);
		//x+=1.0;
    mpfr_add(a,a,z[ja+2],R);
		//a+=z[ja+2];
    mpfr_mul(tmp,z[ja+2],x,R);
    mpfr_add(b,b,tmp,R);
		//b+=z[ja+2]*x;
	}

  mpfr_div(a,a,xa,R);
	//a/=xa;
  mpfr_mul(tmp,xa,xa,R);
  mpfr_add_ui(tmp,tmp,2,R);
  mpfr_mul(tmp,tmp,xa,R);
  mpfr_mul_ui(b,b,12,R);
  mpfr_div(b,b,tmp,R);
	//b=b*12.0/((xa*xa+2.0)*xa);
  mpfr_mul(z0,b,xb,R);
  mpfr_sub(z0,a,z0,R);
	//z0=a-b*xb;
  mpfr_sub(zn,xn,xb,R);
  mpfr_mul(zn,zn,b,R);
  mpfr_add(zn,zn,a,R);
	//zn=a+b*(xn-xb);
  
  mpfr_clears(xn, xa, xb, x, a, b, tmp,x1, x2,NULL);
}

void qtile (mpfr_t ret, const int &nn, mpfr_t a[], const int &ir)
{
	mpfr_t q, r;		/* Initializations by KD2BD */
  mpfr_inits(q,r,NULL);
  mpfr_set_ui(q,0,R);
	int m, n, i, j, j1=0, i0=0, k;	/* Initializations by KD2BD */
	bool done=false;
	bool goto10=true;

	m=0;
	n=nn;
	k=mymin(mymax(0,ir),n);

	while (!done)
	{
		if (goto10)
		{
			mpfr_set(q,a[k],R);
			i0=m;
			j1=n;
		}

		i=i0;

		while (i<=n && mpfr_cmp(a[i],q)>=0)
			i++;

		if (i>n)
			i=n;
		j=j1;

		while (j>=m && mpfr_cmp(a[j],q)<=0)
			j--;

		if (j<m)
			j=m;

		if (i<j)
		{
			mpfr_set(r,a[i],R);
			mpfr_set(a[i],a[j],R);
			mpfr_set(a[j],r,R);
			i0=i+1;
			j1=j-1;
			goto10=false;
		}

		else if (i<k)
		{
			mpfr_set(a[k],a[i],R);
			mpfr_set(a[i],q,R);
			m=i+1;
			goto10=true;
		}

		else if (j>k)
		{
			mpfr_set(a[k],a[j],R);
			mpfr_set(a[j],q,R);
			n=j-1;
			goto10=true;
		}

		else
			done=true;
	}
  
  mpfr_set(ret,q,R);
  if(VERBOSE) mpfr_fprintf(stderr,"QTILE: q = %Rf, r = %Rf\n",q,r);
  mpfr_clears(q,r,NULL);
}

void qerf(mpfr_t qerfv, const mpfr_t z)
{
	double b1=0.319381530, b2=-0.356563782, b3=1.781477937;
	double b4=-1.821255987, b5=1.330274429;
	double rp=4.317008, rrt2pi=0.398942280;
	mpfr_t t, x, tmp;

  mpfr_inits(t, x, tmp,R,NULL);
	mpfr_set(x,z,R);
	mpfr_abs(t,x,R);

	if (mpfr_cmp_d(t,10.0)>=0)
		mpfr_set_ui(qerfv,0,R);
	else
	{
    mpfr_add_d(t,t,rp,R);
    mpfr_d_div(t,rp,t,R);
		//t=rp/(t+rp);
    mpfr_mul_d(tmp,t,b5,R);
    mpfr_add_d(tmp,tmp,b4,R);
    mpfr_mul(tmp,tmp,t,R);
    mpfr_add_d(tmp,tmp,b3,R);
    mpfr_mul(tmp,tmp,t,R);
    mpfr_add_d(tmp,tmp,b2,R);
    mpfr_mul(tmp,tmp,t,R);
    mpfr_add_d(tmp,tmp,b1,R);
    mpfr_mul(tmp,tmp,t,R);
    mpfr_mul_d(tmp,tmp,rrt2pi,R); // tmp = rrt2pi * ((((b5*t + b4)*t + b3)*t + b2)*t + b1)*t
    mpfr_mul(qerfv,x,x,R);
    mpfr_mul_d(qerfv,qerfv,-0.5,R);
    mpfr_exp(qerfv,qerfv,R);
    mpfr_mul(qerfv,qerfv,tmp,R);
		//qerfv=exp(-0.5*x*x) * rrt2pi * ((((b5*t + b4)*t + b3)*t + b2)*t + b1)*t;
	}

	if (mpfr_cmp_d(x,0.0)<0) mpfr_d_sub(qerfv,1.0,qerfv,R);
  //qerfv=1.0-qerfv;
  
  mpfr_clears(t, x, tmp,R,NULL);
}

void d1thx(mpfr_t d1thxv, const mpfr_t pfl[], const mpfr_t i0, const mpfr_t i1)
{
	int np, ka, kb, n, k, j;
	mpfr_t sn, xa, xb, x1, x2, tmp;
  mpfr_inits(sn, xa, xb, x1, x2, tmp,NULL);
  mpfr_set(x1,i0,R);
  mpfr_set(x2,i1,R);
	mpfr_t *s;

	np=mpfr_get_ui(pfl[0],R);
  mpfr_div(xa,x1,pfl[1],R);
	//xa=x1/pfl[1];
  mpfr_div(xb,x2,pfl[1],R);
	//xb=x2/pfl[1];
  mpfr_set_ui(d1thxv,0,R);
	//d1thxv=0.0;

  mpfr_sub(tmp,xb,xa,R);
	if (mpfr_cmp_d(tmp,2.0)<0){  // exit out
    mpfr_clears(sn, xa, xb, x1, x2, tmp, NULL);
		return;
  }

  mpfr_sub(tmp,xb,xa,R);
  mpfr_add_ui(tmp,tmp,8,R);
  mpfr_mul_d(tmp,tmp,0.1,R);
  ka = mpfr_get_ui(tmp,R);
	//ka=(int)(0.1*(xb-xa+8.0));
  ka=mymin(mymax(4,ka),25);
	n=10*ka-5;
	kb=n-ka+1;
	mpfr_set_ui(sn,n-1,R);
	
  // malloc & init...
  assert((s=new mpfr_t[n+2])!=0);
  for(j = 0; j < n+2; j++) mpfr_init(s[j]);
  
	mpfr_set(s[0],sn,R);
	mpfr_set_ui(s[1],1,R);
  mpfr_sub(xb,xb,xa,R);
  mpfr_div(xb,xb,sn,R);
	//xb=(xb-xa)/sn;
  mpfr_add_ui(tmp,xa,1,R);
  k=mpfr_get_ui(tmp,R);
	//k=(int)(xa+1.0);
  mpfr_sub_ui(xa,xa,k,R);
	//xa-=(double)k;

	for (j=0; j<n; j++)
	{
		while (mpfr_cmp_d(xa,0.0)>0 && k<np)
		{
			mpfr_sub_ui(xa,xa,1,R);
      //xa-=1.0;
			++k;
		}

    mpfr_sub(tmp,pfl[k+2],pfl[k+1],R);
    mpfr_mul(tmp,tmp,xa,R);
    mpfr_add(s[j+2],pfl[k+2],tmp,R);
		//s[j+2]=pfl[k+2]+(pfl[k+2]-pfl[k+1])*xa;
    mpfr_add(xa,xa,xb,R);
		//xa=xa+xb;
	}

  if(VERBOSE) mpfr_fprintf(stderr,"D1THX: sn = %Rf, xa = %Rf, xb = %Rf\n",sn,xa,xb);
  
  mpfr_set_ui(tmp,0,R);
	z1sq1(s,tmp,sn,xa,xb);
  mpfr_sub(xb,xb,xa,R);
  mpfr_div(xb,xb,sn,R);
	//xb=(xb-xa)/sn;

	for (j=0; j<n; j++)
	{
    mpfr_sub(s[j+2],s[j+2],xa,R);
		//s[j+2]-=xa;
    mpfr_add(xa,xa,xb,R);
		//xa=xa+xb;
	}
  
	qtile(d1thxv,n-1,s+2,ka-1);
  qtile(tmp,n-1,s+2,kb-1);
  mpfr_sub(d1thxv,d1thxv,tmp,R); // d1thxv = qtile(n-1,s+2,ka-1)-qtile(n-1,s+2,kb-1);
  if(VERBOSE) mpfr_fprintf(stderr,"D1THX: d1thxv = %Rf, kb = %d, ka = %d\n",d1thxv,kb,ka);
  
  mpfr_sub(tmp,x2,x1,R);
  mpfr_neg(tmp,tmp,R);
  mpfr_div_ui(tmp,tmp,50e3,R);
  mpfr_exp(tmp,tmp,R);
  mpfr_mul_d(tmp,tmp,0.8,R);
  mpfr_d_sub(tmp,1.0,tmp,R);
  mpfr_div(d1thxv,d1thxv,tmp,R);
	//d1thxv/=1.0-0.8*exp(-(x2-x1)/50.0e3);
  
  // cleanup
  mpfr_clears(sn, xa, xb, x1, x2, tmp, NULL);
  for(j = 0; j < n+2; j++) mpfr_clear(s[j]);
	delete[] s;
}

void qlrpfl (const mpfr_t pfl[], int klimx, int mdvarx, prop_type &prop, propa_type &propa, propv_type &propv)
{
	int np, j;
	mpfr_t xl[2], q, za, zb, tmp,tmp2;
  mpfr_inits(xl[0],xl[1],q,za,zb,tmp,tmp2,NULL);

  if(VERBOSE) mpfr_fprintf(stderr,"QLRPFL: pfl[0] = %Rf, pfl[1] = %Rf\n",pfl[0],pfl[1]);
	mpfr_mul(prop.dist,pfl[0],pfl[1],R);
	np=mpfr_get_ui(pfl[0],R);
	hzns(pfl,prop);

	for (j=0; j<2; j++){
    mpfr_mul_d(tmp,prop.dl[j],0.1,R);
    mpfr_mul_d(xl[j],prop.hg[j],15.0,R);
    mymin(xl[j],xl[j],tmp);
		//xl[j]=mymin(15.0*prop.hg[j],0.1*prop.dl[j]);
  }

  mpfr_sub(xl[1],prop.dist,xl[1],R);
	//xl[1]=prop.dist-xl[1];
  
	d1thx(prop.dh,pfl,xl[0],xl[1]);

  mpfr_add(tmp,prop.dl[0],prop.dl[1],R);
  mpfr_mul_d(tmp2,prop.dist,1.5,R);
	if (mpfr_cmp(tmp,tmp2)>0)
	{
		z1sq1(pfl,xl[0],xl[1],za,zb);
    FORTRAN_DIM(tmp,pfl[2],za);
    mpfr_add(prop.he[0],prop.hg[0],tmp,R);
		//prop.he[0]=prop.hg[0]+FORTRAN_DIM(pfl[2],za);
    FORTRAN_DIM(tmp,pfl[np+2],zb);
    mpfr_add(prop.he[1],prop.hg[1],tmp,R);
		//prop.he[1]=prop.hg[1]+FORTRAN_DIM(pfl[np+2],zb);
    
    if(VERBOSE) mpfr_fprintf(stderr,"QLRPFL: prop.he[0] = %Rf, prop.he[1] = %Rf, za = %Rf, zb = %Rf\n",prop.he[0],prop.he[1],za,zb);
    if(VERBOSE) mpfr_fprintf(stderr,"QLRFPL: prop.dl[0] = %Rf, prop.dl[1] = %Rf, prop.gme = %Rf, prop.dh = %Rf\n",prop.dl[0],prop.dl[1],prop.gme,prop.dh);
    
    for (j=0; j<2; j++){
      mpfr_set_ui(tmp,5,R);
      mymax(tmp,prop.he[j],tmp);
      mpfr_div(tmp,prop.dh,tmp,R);
      mpfr_sqrt(tmp,tmp,R);
      mpfr_mul_d(tmp,tmp,-0.07,R);
      mpfr_exp(tmp,tmp,R); // tmp = exp(-0.07*sqrt(prop.dh/mymax(prop.he[j],5.0)))
      mpfr_mul_ui(tmp2,prop.he[j],2,R);
      mpfr_div(tmp2,tmp2,prop.gme,R);
      mpfr_sqrt(tmp2,tmp2,R); // tmp2 = sqrt(2.0*prop.he[j]/prop.gme)
      mpfr_mul(prop.dl[j],tmp,tmp2,R);
			//prop.dl[j]=sqrt(2.0*prop.he[j]/prop.gme) * exp(-0.07*sqrt(prop.dh/mymax(prop.he[j],5.0)));
    }
    
    mpfr_add(q,prop.dl[0],prop.dl[1],R);
    if(VERBOSE) mpfr_fprintf(stderr,"QLRFPL: prop.dl[0] = %Rf, prop.dl[1] = %Rf, q = %Rf\n",prop.dl[0],prop.dl[1],q);
		//q=prop.dl[0]+prop.dl[1];

		if (mpfr_cmp(q,prop.dist)<=0)
		{
      mpfr_div(q,prop.dist,q,R);
      mpfr_pow_ui(q,q,2,R);
			/* q=pow(prop.dist/q,2.0); */
			//q=((prop.dist/q)*(prop.dist/q));

			for (j=0; j<2; j++)
			{
				mpfr_mul(prop.he[j],prop.he[j],q,R);
        
        mpfr_set_ui(tmp,5,R);
        mymax(tmp,prop.he[j],tmp);
        mpfr_div(tmp,prop.dh,tmp,R);
        mpfr_sqrt(tmp,tmp,R);
        mpfr_mul_d(tmp,tmp,-0.07,R);
        mpfr_exp(tmp,tmp,R); // tmp = exp(-0.07*sqrt(prop.dh/mymax(prop.he[j],5.0)))
        mpfr_mul_ui(tmp2,prop.he[j],2,R);
        mpfr_div(tmp2,tmp2,prop.gme,R);
        mpfr_sqrt(tmp2,tmp2,R); // tmp2 = sqrt(2.0*prop.he[j]/prop.gme)
        mpfr_mul(prop.dl[j],tmp,tmp2,R);
        
				//prop.dl[j]=sqrt(2.0*prop.he[j]/prop.gme)*exp(-0.07*sqrt(prop.dh/mymax(prop.he[j],5.0)));
			}
      
		}

		for (j=0; j<2; j++)
		{
      mpfr_mul_ui(q,prop.he[j],2,R);
      mpfr_div(q,q,prop.gme,R);
      mpfr_sqrt(q,q,R);
			//q=sqrt(2.0*prop.he[j]/prop.gme);
      mpfr_div(tmp,q,prop.dl[j],R);
      mpfr_sub_d(tmp,tmp,1.0,R);
      mpfr_mul(tmp,tmp,prop.dh,R);
      mpfr_mul_d(tmp,tmp,0.65,R);
      mpfr_mul_ui(tmp2,prop.he[j],2,R);
      mpfr_sub(tmp,tmp,tmp2,R);
      mpfr_div(prop.the[j],tmp,q,R);
			//prop.the[j]=(0.65*prop.dh*(q/prop.dl[j]-1.0) - 2.0*prop.he[j])/q;
    }
	}
	else
	{
    mpfr_mul_d(tmp,prop.dl[0],0.9,R);
		z1sq1(pfl,xl[0],tmp,za,q);
    mpfr_mul_d(tmp,prop.dl[1],0.9,R);
    mpfr_sub(tmp,prop.dist,tmp,R);
		z1sq1(pfl,tmp,xl[1],q,zb);
    FORTRAN_DIM(tmp,pfl[2],za);
    mpfr_add(prop.he[0],prop.hg[0],tmp,R);
		//prop.he[0]=prop.hg[0]+FORTRAN_DIM(pfl[2],za);
    FORTRAN_DIM(tmp,pfl[np+2],zb);
    if(VERBOSE) mpfr_fprintf(stderr,"QLRPFL: tmp = %Rf, zb = %Rf, pfl[np+2] = %Rf, za = %Rf, q = %Rf\n",tmp,zb,pfl[np+2],za,q);
    mpfr_add(prop.he[1],prop.hg[1],tmp,R);
		//prop.he[1]=prop.hg[1]+FORTRAN_DIM(pfl[np+2],zb);
    if(VERBOSE) mpfr_fprintf(stderr,"QLRFPL: he0 = %Rf, he1 = %Rf, hg0 = %Rf, hg1 = %Rf\n",prop.he[0],prop.he[1],prop.hg[0],prop.hg[1]);
	}

	prop.mdp=-1;
	propv.lvar=mymax(propv.lvar,3);

	if (mdvarx>=0)
	{
		propv.mdvar=mdvarx;
		propv.lvar=mymax(propv.lvar,4);
	}

	if (klimx>0)
	{
		propv.klim=klimx;
		propv.lvar=5;
	}

  mpfr_set_ui(tmp,0,R);
  if(VERBOSE) mpfr_fprintf(stderr,"QLRFPL: he0 = %Rf, he1 = %Rf\n",prop.he[0],prop.he[1]);
	lrprop(tmp,prop,propa,1); // init & run
  lrprop(tmp,prop,propa,-1); // cleanup
}

//********************************************************
//* Point-To-Point Mode Calculations                     *
//********************************************************

void point_to_point(const mpfr_t elev[], const mpfr_t i0, const mpfr_t i1, 
  const mpfr_t i2, const mpfr_t i3, const mpfr_t i4, 
  const mpfr_t i5, int radio_climate, int pol, const mpfr_t i6, 
  const mpfr_t i7, mpfr_t dbloss, char *strmode, int &errnum)
{
	// pol: 0-Horizontal, 1-Vertical
	// radio_climate: 1-Equatorial, 2-Continental Subtropical, 3-Maritime Tropical,
	//                4-Desert, 5-Continental Temperate, 6-Maritime Temperate, Over Land,
	//                7-Maritime Temperate, Over Sea
	// conf, rel: .01 to .99
	// elev[]: [num points - 1], [delta dist(meters)], [height(meters) point 1], ..., [height(meters) point n]
	// errnum: 0- No Error.
	//         1- Warning: Some parameters are nearly out of range.
	//                     Results should be used with caution.
	//         2- Note: Default parameters have been substituted for impossible ones.
	//         3- Warning: A combination of parameters is out of range.
	//                     Results are probably invalid.
	//         Other-  Warning: Some parameters are out of range.
	//                          Results are probably invalid.

	prop_type   prop;
	propv_type  propv;
	propa_type  propa;
  mpfr_t zsys,zc,zr,eno,enso,q,dkm,xkm,fs,tmp,tht_m,rht_m,eps_dielect,sgm_conductivity,eno_ns_surfref,frq_mhz,conf,rel;
  init_props(prop,propv,propa);
  mpfr_inits(tmp,zsys,zc,zr,eno,enso,q,dkm,xkm,fs,tht_m,rht_m,eps_dielect,sgm_conductivity,eno_ns_surfref,frq_mhz,conf,rel,NULL);
  mpfr_set_ui(zsys,0,R);
  mpfr_set(tht_m,i0,R);
  mpfr_set(rht_m,i1,R);
  mpfr_set(eps_dielect,i2,R);
  mpfr_set(sgm_conductivity,i3,R);
  mpfr_set(eno_ns_surfref,i4,R);
  mpfr_set(frq_mhz,i5,R);
  mpfr_set(conf,i6,R);
  mpfr_set(rel,i7,R);
	long ja, jb, i, np;
	
	mpfr_set(prop.hg[0],tht_m,R);
	mpfr_set(prop.hg[1],rht_m,R);
	propv.klim=radio_climate;
	prop.kwx=ITM_NO_ERROR;
	propv.lvar=5;
	prop.mdp=-1;
	qerfi(zc,conf);
	qerfi(zr,rel);
	np=mpfr_get_ui(elev[0],R);
  mpfr_mul(dkm,elev[1],elev[0],R);
  mpfr_div_ui(dkm,dkm,1000,R);
	//dkm=(elev[1]*elev[0])/1000.0;
  mpfr_div_ui(xkm,elev[1],1000,R);
	//xkm=elev[1]/1000.0;
	mpfr_set(eno,eno_ns_surfref,R);
	mpfr_set_ui(enso,0,R);
	mpfr_set(q,enso,R);

	if (mpfr_cmp_d(q,0.0)<=0)
	{
		/* ja = 3.0 + 0.1 * elev[0]; */
    mpfr_mul_d(tmp,elev[0],0.1,R);
    mpfr_add_ui(tmp,tmp,3,R);
    ja = mpfr_get_ui(tmp,R);
		//ja=(long)(3.0+0.1* elev[0]);
		jb=np-ja+6;

		for (i=ja-1; i<jb; ++i){
			mpfr_add(zsys,zsys,elev[i],R);
    }

    mpfr_div_ui(zsys,zsys,(jb-ja+1),R);
		//zsys/=(jb-ja+1);
		mpfr_set(q,eno,R);
	}

	propv.mdvar=12;
	qlrps(frq_mhz,zsys,q,pol,eps_dielect,sgm_conductivity,prop);
	qlrpfl(elev,propv.klim,propv.mdvar,prop,propa,propv);
  mpfr_div_ui(fs,prop.dist,1000,R);
  mpfr_log10(fs,fs,R);
  mpfr_mul_ui(fs,fs,20,R);
  mpfr_log10(tmp,frq_mhz,R);
  mpfr_mul_ui(tmp,tmp,20,R);
  mpfr_add(fs,fs,tmp,R);
  mpfr_add_d(fs,fs,32.45,R);
	//fs=32.45+20.0*log10(frq_mhz)+20.0*log10(prop.dist/1000.0);
  mpfr_sub(q,prop.dist,propa.dla,R);
	//q=prop.dist-propa.dla;
  if(VERBOSE) mpfr_fprintf(stderr,"POINT_TO_POINT: prop.dist = %Rf, prop.dla = %Rf, fs = %Rf, q = %Rf\n",prop.dist,propa.dla,fs,q);

  i = mpfr_get_si(q,R);
  
	if (i<0)
		strcpy(strmode,"Line-Of-Sight Mode");

	else
	{
		if (i==0)
			strcpy(strmode,"Single Horizon");

		else if (i>0.0)
			strcpy(strmode,"Double Horizon");

		if (mpfr_cmp(prop.dist,propa.dlsa)<=0 || mpfr_cmp(prop.dist,propa.dx)<=0)
			strcat(strmode,", Diffraction Dominant");

		else if (mpfr_cmp(prop.dist,propa.dx)>0)
			strcat(strmode, ", Troposcatter Dominant");
	}

  mpfr_set_ui(tmp,0,R);
	avar(dbloss,zr,tmp,zc,prop,propv,1);
  mpfr_add(dbloss,dbloss,fs,R);
  if(VERBOSE) mpfr_fprintf(stderr,"POINT_TO_POINT: dbloss = %Rf, zr = %Rf, zc = %Rf\n",dbloss,zr,zc);
  avar(dbloss,zr,tmp,zc,prop,propv,-1); // cleanup static vars
	errnum=prop.kwx;
  
  clear_props(prop,propv,propa);
  mpfr_clears(tmp,zsys,zc,zr,eno,enso,q,dkm,xkm,fs,tht_m,rht_m,eps_dielect,sgm_conductivity,eno_ns_surfref,frq_mhz,conf,rel,NULL);
}

double ITMVersion()
{
	return 7.0;
}

/************************************************************************************
 * Everything below added by Caleb Phillips to make this into a stand-alone program *
 * Most of the above taken directly from itm.cpp, distributed with Splat! 1.3.0     *
 ************************************************************************************/

void deg_to_rad(mpfr_t r, const mpfr_t i0)
{
  mpfr_t d;
  mpfr_init(d);
  mpfr_set(d,i0,R);
  mpfr_const_pi(r,R);
  mpfr_mul(r,d,r,R);
  mpfr_div_ui(r,r,180,R);
  mpfr_clear(d);
}

// based on Distance() in splat.cpp
// NOTE: This will return 0 if the precision (in terms of exponent size) is less than 37 bits this is because
//       the sum of sin(lat1)*sin(lat2) and cos(lat1)*cos(lat2)*cos(lng1-lng2) is only very slightly below
//       1.0. If it gets rounded up to 1.0, then acos will return 0 which is meaningless. This is a known
//       imprecision which results in the "spherical law of cosines" version of the great circle ditance
//       when used for small distances.
/*void great_circle_distance_km(mpfr_t r,const mpfr_t i0, const mpfr_t i1, const mpfr_t i2, const mpfr_t i3)
{
  mpfr_t r_km,tmp1,tmp2,lng1,lat1,lng2,lat2;
  
  mpfr_init_set_d(r_km,6378.1,R);
  mpfr_inits(tmp1,tmp2,lng1,lat1,lng2,lat2,NULL);
  
  mpfr_set(lng1,i0,R);
  mpfr_set(lat1,i1,R);
  mpfr_set(lng2,i2,R);
  mpfr_set(lat2,i3,R);
  
  deg_to_rad(lng1,lng1);
  deg_to_rad(lng2,lng2);
  deg_to_rad(lat1,lat1);
  deg_to_rad(lat2,lat2);
  
  mpfr_sin(tmp1,lat1,R);
  mpfr_sin(tmp2,lat2,R);
  mpfr_mul(tmp1,tmp1,tmp2,R); // tmp1 = sin(lat1)*sin(lat2)
  
  mpfr_cos(lat1,lat1,R);
  mpfr_cos(lat2,lat2,R);
  mpfr_sub(tmp2,lng1,lng2,R);
  mpfr_cos(tmp2,tmp2,R);
  mpfr_mul(tmp2,tmp2,lat1,R);
  mpfr_mul(tmp2,tmp2,lat2,R); // tmp2 = cos(lat1)*cos(lat2)*cos(lng1-lng2)
  mpfr_add(r,tmp1,tmp2,R);
  if(VERBOSE) mpfr_fprintf(stderr,"GREAT_CIRCLE_DISTANCE: acos given %Rf = %Rf + %Rf\n",r,tmp1,tmp2); 
  mpfr_acos(r,r,R);
  if(VERBOSE) mpfr_fprintf(stderr,"GREAT_CIRCLE_DISTANCE: acos returned %Rf\n",r);
  mpfr_mul(r,r_km,r,R); // r = r_km*acos(tmp1+tmp2)
  
  mpfr_clears(r_km,tmp1,tmp2,lng1,lat1,lng2,lat2,NULL);
}*/

// Vicenty-formula based GCD which is "precise" for all points on the sphere
// This one seems to need at least 17 bits of exponent to calculate a reasonable answer (i.e., non-zero)
// when distances are on the order of tens of meters (42 meters in my tests)
void great_circle_distance_km(mpfr_t r,const mpfr_t i0, const mpfr_t i1, const mpfr_t i2, const mpfr_t i3)
{
  mpfr_t r_km,tmp1,tmp2,tmp3,tmp4,coslat2,sinlat1,dlng,lng1,lat1,lng2,lat2;
  
  mpfr_init_set_d(r_km,6378.1,R);
  mpfr_inits(tmp1,tmp2,tmp3,tmp4,dlng,lng1,coslat2,sinlat1,lat1,lng2,lat2,NULL);
  
  mpfr_set(lng1,i0,R);
  mpfr_set(lat1,i1,R);
  mpfr_set(lng2,i2,R);
  mpfr_set(lat2,i3,R);
  
  deg_to_rad(lng1,lng1);
  deg_to_rad(lng2,lng2);
  deg_to_rad(lat1,lat1);
  deg_to_rad(lat2,lat2);
  
  mpfr_sub(dlng,lng1,lng2,R); // precompute a couple things
  mpfr_cos(coslat2,lat2,R);
  mpfr_sin(sinlat1,lat1,R);
  
  mpfr_sin(tmp1,dlng,R);
  mpfr_mul(tmp1,coslat2,tmp1,R);
  mpfr_pow_ui(tmp1,tmp1,2,R); // tmp1 = (cos(lat2)*sin(lng1-lng2))^2
  
  mpfr_cos(tmp2,lat1,R);
  mpfr_sin(tmp3,lat2,R);
  mpfr_mul(tmp2,tmp2,tmp3,R); // tmp2 = cos(lat1)*sin(lat2)
  
  mpfr_cos(tmp3,dlng,R);
  mpfr_mul(tmp3,tmp3,coslat2,R);
  mpfr_mul(tmp3,tmp3,sinlat1,R); // tmp3 = sin(lat1)*cos(lat2)*cos(lng1-lng2)
  
  mpfr_sub(tmp2,tmp2,tmp3,R);
  mpfr_pow_ui(tmp2,tmp2,2,R);
  mpfr_add(tmp1,tmp1,tmp2,R);
  mpfr_sqrt(tmp1,tmp1,R); // tmp1 = sqrt((cos(lat2)*sin(lng1-lng2))^2 + (cos(lat1)*sin(lat2) - sin(lat1)*cos(lat2)*cos(lng1-lng2))^2)
  
  mpfr_sin(tmp2,lat2,R);
  mpfr_mul(tmp2,tmp2,sinlat1,R);
  
  mpfr_cos(tmp3,lat1,R);
  mpfr_mul(tmp3,tmp3,coslat2,R);
  mpfr_cos(tmp4,dlng,R);
  mpfr_mul(tmp3,tmp3,tmp4,R);
  mpfr_add(tmp2,tmp2,tmp3,R); // tmp2 = sin(lat1)*sin(lat2) + cos(lat1)*cos(lat2)*cos(lng1-lng2)
  
  mpfr_atan2(r,tmp1,tmp2,R);
  mpfr_mul(r,r,r_km,R);
}

void usage(){
	printf("Usage: itm <climate-code> <rel. perm.> <conductivity> <freq. MHz> <num-points> <precision> < path.txt\n\n\
       path.txt should have four whitspace separated columns:\n\n\
           longitude in degrees\n\
           latitude in degrees\n\
           height above ground in m\n\
           elevation above sea-level in m\n\n\
      It is assumed that the first point is the transmitter and\n\
      the last point is the receiver and that the points are \n\
      equally spaced.\n");
	exit(USAGE_ERROR);

}

/**
 Earth dielectric constants and conductivity values are as follows:

	 		  Dielectric Constant   Conductivity
	Salt water       :        80		    5.000
	Good ground      :        25		    0.020
	Fresh water      :        80		    0.010
	Marshy land      :        12		    0.007
	Farmland, forest :        15		    0.005
	Average ground   :        15		    0.005
	Mountain, sand   :        13		    0.002
	City             :         5		    0.001
	Poor ground      :         4		    0.001

Radio climate codes are defined as follows:

	1: Equatorial (Congo)
	2: Continental Subtropical (Sudan)
	3: Maritime Subtropical (West coast of Africa)
	4: Desert (Sahara)
	5: Continental Temperate
	6: Maritime Temperate, over land (UK and west coasts of US & EU)
	7: Maritime Temperate, over sea

The Continental Temperate climate (5) is common to large land masses in
the temperate zone, such as the United States.  For paths shorter than
100 km, there is little difference between Continental and Martitime
Temperate climates.

The 7th and 8th parameters in the .lrp file correspond to the statistical
analysis provided by the Longley-Rice model.  In this example, SPLAT!
will return the maximum path loss occurring 50% of the time (fraction
of time) in 50% of situations (fraction of situations).  Use a fraction
of time of 0.90 for digital television, 0.50 for analog.
  
  */

int main(int argc, char* argv[])
{
  mpfr_t *elev;
  mpfr_t tht_m, rht_m, dx, dbloss;
	int i, errnum, radio_climate, pol;
  const int BUFLEN = 512;
	char buffer[BUFLEN],lng[BUFLEN],lat[BUFLEN],h[BUFLEN],dem[BUFLEN];
	mpfr_t eps,sgm,eno,f,conf,rel,tx_lng,tx_lat,tmp1,tmp2;
  
  P = atoi(argv[6]);
  mpfr_set_default_prec(P);
  if(P == 53){
    // emulate binary64 in IEEE 754-2008
    mpfr_set_emin (-1073);
    mpfr_set_emax (1024);
  }
  
  if(argc < 6+1) usage();
  radio_climate = atoi(argv[1]);
  mpfr_init_set_str(eps,argv[2],10,R);
  mpfr_init_set_str(sgm,argv[3],10,R);
  mpfr_init_set_str(f,argv[4],10,R);
  
	// allocate elev array
	int elev_size = atoi(argv[5])+2;
	elev = (mpfr_t *)malloc((elev_size)*sizeof(mpfr_t));
	if(elev == NULL) return MALLOC_ERROR;

	// read in data lines
	i = 0;
	while(fscanf(stdin,"%s %s %s %s",lng,lat,h,dem) == 4){
		mpfr_init(elev[i+2]);
		mpfr_set_str(elev[i+2],dem,10,R);
    if(VERBOSE) mpfr_fprintf(stderr,"MAIN: Initializing elev[%d] to %Rf\n",i+2,elev[i+2]);

		// first point is tx
		if(i == 0){
			mpfr_init_set_str(tht_m,h,10,R);
      mpfr_init_set_str(tx_lng,lng,10,R);
      mpfr_init_set_str(tx_lat,lat,10,R);
		}
		// determine delta-x (in m) using distance between first (tx)
		// and second point
		if(i == 1){
      mpfr_init_set_str(tmp1,lng,10,R);
      mpfr_init_set_str(tmp2,lat,10,R);
      mpfr_init(dx);
      exception_handler("Before great_circle_distance_km()");
			great_circle_distance_km(dx,tx_lng,tx_lat,tmp1,tmp2);
      exception_handler("After great_circle_distance_km()");
      mpfr_mul_ui(dx,dx,1000,R);
		}

		i++;
	}

	if(i < 2) usage();

	mpfr_init_set_str(rht_m,h,10,R);
  
  mpfr_init(elev[0]);
  mpfr_init(elev[1]);
	mpfr_set_ui(elev[0],(unsigned long int)i-1,R);
	mpfr_set(elev[1],dx,R);

	if(VERBOSE) mpfr_fprintf(stderr,"MAIN: dx = %Rf, np-1 = %Rf, rht_m = %Rf, tht_m = %Rf\n",dx,elev[0],rht_m,tht_m);
  
	// default paramter values

  //eps = 15.0;        // relative permitivity of the ground
	//sgm = 0.005;       // conductivitiy of the ground (Siemens/m)
	//f = 2412.0;        // carrier frequency in MHz
  //radio_climate = 5; // radio climate category (1-7)  
  pol = 0;                                   // antenna polarity (0 => hor, 1 => ver)
  mpfr_init_set_d(eno,301.0,R);       // atmospheric bending constant (N-units)
	mpfr_init_set_d(conf,0.5,R);        // Fraction of situations/locations (shouldn't matter for point_to_point mode?)
	mpfr_init_set_d(rel,0.9,R);         // Fraction of time (0.9 for digital, 0.5 for analog...)
  
  if(VERBOSE) mpfr_fprintf(stderr,"MAIN: eps = %Rf, sgm = %Rf, f = %Rf, radio_climate = %d\n",eps,sgm,f,radio_climate);
  if(VERBOSE) mpfr_fprintf(stderr,"MAIN: eno = %Rf, pol = %d, conf = %Rf, rel = %Rf\n",eno,pol,conf,rel);
  
	// do it
  exception_handler("Before point_to_point()");
	point_to_point(elev,tht_m,rht_m,eps,sgm,eno,f,radio_climate,pol,conf,rel,dbloss,buffer,errnum);

	mpfr_fprintf(stdout,"%.08Rf|%s|%d\n",dbloss,buffer,errnum);
  
  // cleanup
  for(i = 0; i < elev_size; i++) mpfr_clear(elev[i]);
	free(elev);
  mpfr_clears(tht_m, rht_m, dx, dbloss,NULL);

	return ITM_NO_ERROR;
}
